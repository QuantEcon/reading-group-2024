# **Lecture Draft: Why Study GDP?**

This lecture will use Python, pandas, and matplotlib to introduce GDP as an economic concept by identifying some of the factors using correlations.


```python
!pip install wbgapi
!pip install pandas-datareader
```

    Requirement already satisfied: wbgapi in /usr/local/lib/python3.10/dist-packages (1.0.12)
    Requirement already satisfied: requests in /usr/local/lib/python3.10/dist-packages (from wbgapi) (2.31.0)
    Requirement already satisfied: PyYAML in /usr/local/lib/python3.10/dist-packages (from wbgapi) (6.0.1)
    Requirement already satisfied: tabulate in /usr/local/lib/python3.10/dist-packages (from wbgapi) (0.9.0)
    Requirement already satisfied: charset-normalizer<4,>=2 in /usr/local/lib/python3.10/dist-packages (from requests->wbgapi) (3.3.2)
    Requirement already satisfied: idna<4,>=2.5 in /usr/local/lib/python3.10/dist-packages (from requests->wbgapi) (3.6)
    Requirement already satisfied: urllib3<3,>=1.21.1 in /usr/local/lib/python3.10/dist-packages (from requests->wbgapi) (2.0.7)
    Requirement already satisfied: certifi>=2017.4.17 in /usr/local/lib/python3.10/dist-packages (from requests->wbgapi) (2024.2.2)
    Requirement already satisfied: pandas-datareader in /usr/local/lib/python3.10/dist-packages (0.10.0)
    Requirement already satisfied: lxml in /usr/local/lib/python3.10/dist-packages (from pandas-datareader) (4.9.4)
    Requirement already satisfied: pandas>=0.23 in /usr/local/lib/python3.10/dist-packages (from pandas-datareader) (1.5.3)
    Requirement already satisfied: requests>=2.19.0 in /usr/local/lib/python3.10/dist-packages (from pandas-datareader) (2.31.0)
    Requirement already satisfied: python-dateutil>=2.8.1 in /usr/local/lib/python3.10/dist-packages (from pandas>=0.23->pandas-datareader) (2.8.2)
    Requirement already satisfied: pytz>=2020.1 in /usr/local/lib/python3.10/dist-packages (from pandas>=0.23->pandas-datareader) (2023.4)
    Requirement already satisfied: numpy>=1.21.0 in /usr/local/lib/python3.10/dist-packages (from pandas>=0.23->pandas-datareader) (1.25.2)
    Requirement already satisfied: charset-normalizer<4,>=2 in /usr/local/lib/python3.10/dist-packages (from requests>=2.19.0->pandas-datareader) (3.3.2)
    Requirement already satisfied: idna<4,>=2.5 in /usr/local/lib/python3.10/dist-packages (from requests>=2.19.0->pandas-datareader) (3.6)
    Requirement already satisfied: urllib3<3,>=1.21.1 in /usr/local/lib/python3.10/dist-packages (from requests>=2.19.0->pandas-datareader) (2.0.7)
    Requirement already satisfied: certifi>=2017.4.17 in /usr/local/lib/python3.10/dist-packages (from requests>=2.19.0->pandas-datareader) (2024.2.2)
    Requirement already satisfied: six>=1.5 in /usr/local/lib/python3.10/dist-packages (from python-dateutil>=2.8.1->pandas>=0.23->pandas-datareader) (1.16.0)



```python
import os
import pandas as pd
import matplotlib.pyplot as plt
import matplotlib.cm as cm
import numpy as np
from collections import namedtuple
import datetime
import pandas_datareader.data as web
import scipy

import plotly.express as px

import wbgapi as wb

import pandas_datareader.data as web
```


```python
from google.colab import drive
drive.mount('/content/drive')
```

    Drive already mounted at /content/drive; to attempt to forcibly remount, call drive.mount("/content/drive", force_remount=True).



```python
# Set the working directory
os.chdir("/content/drive/MyDrive/gdp_lecture")
```

# 1 What is GDP

## 1.1 Overview

Gross Domestic Product (`GDP`) is the primary indicator used to exmine the economic performance of a country, measuring the total market value of all goods and services produced within a country over a specified period.

GDP is usually analysed in two forms: Nominal GDP, which is valued at current market prices, and Real GDP, which is adjusted for inflation to reflect the true economic growth. Nominal GDP can be adjust to Real GDP using the formula: `Real GDP = Nominal GDP x (Price level in base year ÷ Price level in current year)`.

The following graph presents a visual comparison between Nominal GDP and Real GDP per quarter over time in the United States:



```python
start_date = datetime.datetime(1949, 1, 1)
end_date = datetime.datetime(2023, 10, 1)

nominal_gdp = web.DataReader('GDP', 'fred', start_date, end_date)
real_gdp = web.DataReader('GDPC1', 'fred', start_date, end_date)

plt.figure(figsize=(10, 6))
plt.plot(nominal_gdp.index, nominal_gdp['GDP'], label='Nominal GDP')
plt.plot(real_gdp.index, real_gdp['GDPC1'], label='Real GDP', linestyle='--')

plt.title('Nominal vs. Real GDP of US (1949 - 2023)')
plt.xlabel('Year')
plt.ylabel('Billions of Dollars / Billions of Chained 2017 Dollars')
plt.legend()
plt.show()
```


    
![png](Why_GDP_lecture_files/Why_GDP_lecture_7_0.png)
    


Source: Federal Reserve Economic Data (St. Louis Fed)

Real GDP is measured in "billions of chained 2017 dollars",which is a dollar measure that is adjusted for the price change due to inflation and consumer behaviour within the year of 2017. Here are some interesting observations:

- Both Nominal and Real GDP displayed increasing trend since 1949.
- Post-2000, Nominal GDP growth outpaced Real GDP, especially after 2010, indicating inflation's role as a contributing factor.
- 2008 and 2020 saw GDP drops due to the Global Financial Crisis and COVID-19 pandemic, respectively. These crises led to significant GDP contractions, evident in downturns on the graph.

## 1.2 GDP vs. GDP per Capita

GDP per capita can be calculated using the formula `GDP per capita = GDP ÷ population`.

GDP per capital is often a more useful indicator of economic well-being and quality of life. This adjustment also allows comparison of economic well-being across countries with vastly different population sizes.

Consider the following graph of GDP per capita vs. GDP of most countries:  


```python
wb.series.info(q='GDP')
```




<div class="wbgapi"><table>
<thead>
<tr><th>id                  </th><th>value                                                                    </th></tr>
</thead>
<tbody>
<tr><td>EG.GDP.PUSE.KO.PP   </td><td>GDP per unit of energy use (PPP $ per kg of oil equivalent)              </td></tr>
<tr><td>EG.GDP.PUSE.KO.PP.KD</td><td>GDP per unit of energy use (constant 2017 PPP $ per kg of oil equivalent)</td></tr>
<tr><td>EG.USE.COMM.GD.PP.KD</td><td>Energy use (kg of oil equivalent) per $1,000 GDP (constant 2017 PPP)     </td></tr>
<tr><td>NY.GDP.DEFL.KD.ZG   </td><td>Inflation, GDP deflator (annual %)                                       </td></tr>
<tr><td>NY.GDP.DEFL.KD.ZG.AD</td><td>Inflation, GDP deflator: linked series (annual %)                        </td></tr>
<tr><td>NY.GDP.DEFL.ZS      </td><td>GDP deflator (base year varies by country)                               </td></tr>
<tr><td>NY.GDP.DEFL.ZS.AD   </td><td>GDP deflator: linked series (base year varies by country)                </td></tr>
<tr><td>NY.GDP.DISC.CN      </td><td>Discrepancy in expenditure estimate of GDP (current LCU)                 </td></tr>
<tr><td>NY.GDP.DISC.KN      </td><td>Discrepancy in expenditure estimate of GDP (constant LCU)                </td></tr>
<tr><td>NY.GDP.MKTP.CD      </td><td>GDP (current US$)                                                        </td></tr>
<tr><td>NY.GDP.MKTP.CN      </td><td>GDP (current LCU)                                                        </td></tr>
<tr><td>NY.GDP.MKTP.CN.AD   </td><td>GDP: linked series (current LCU)                                         </td></tr>
<tr><td>NY.GDP.MKTP.KD      </td><td>GDP (constant 2015 US$)                                                  </td></tr>
<tr><td>NY.GDP.MKTP.KD.ZG   </td><td>GDP growth (annual %)                                                    </td></tr>
<tr><td>NY.GDP.MKTP.KN      </td><td>GDP (constant LCU)                                                       </td></tr>
<tr><td>NY.GDP.MKTP.PP.CD   </td><td>GDP, PPP (current international $)                                       </td></tr>
<tr><td>NY.GDP.MKTP.PP.KD   </td><td>GDP, PPP (constant 2017 international $)                                 </td></tr>
<tr><td>NY.GDP.PCAP.CD      </td><td>GDP per capita (current US$)                                             </td></tr>
<tr><td>NY.GDP.PCAP.CN      </td><td>GDP per capita (current LCU)                                             </td></tr>
<tr><td>NY.GDP.PCAP.KD      </td><td>GDP per capita (constant 2015 US$)                                       </td></tr>
<tr><td>NY.GDP.PCAP.KD.ZG   </td><td>GDP per capita growth (annual %)                                         </td></tr>
<tr><td>NY.GDP.PCAP.KN      </td><td>GDP per capita (constant LCU)                                            </td></tr>
<tr><td>NY.GDP.PCAP.PP.CD   </td><td>GDP per capita, PPP (current international $)                            </td></tr>
<tr><td>NY.GDP.PCAP.PP.KD   </td><td>GDP per capita, PPP (constant 2017 international $)                      </td></tr>
<tr><td>PA.NUS.PPP          </td><td>PPP conversion factor, GDP (LCU per international $)                     </td></tr>
<tr><td>PA.NUS.PPPC.RF      </td><td>Price level ratio of PPP conversion factor (GDP) to market exchange rate </td></tr>
<tr><td>SL.GDP.PCAP.EM.KD   </td><td>GDP per person employed (constant 2017 PPP $)                            </td></tr>
<tr><td>                    </td><td>27 elements                                                              </td></tr>
</tbody>
</table></div>




```python
data = pd.read_excel('GDP.xlsx', sheet_name='Full Data')

fig = px.scatter(data, x='GDP per capita', y='GDP',
                 hover_name='Country Name', title='GDP per capita vs GDP')


fig.update_layout(
    xaxis_title="GDP per capita ($ thousands)",
    yaxis_title="GDP ($ trillians)"
)


fig.show()
```


<html>
<head><meta charset="utf-8" /></head>
<body>
    <div>            <script src="https://cdnjs.cloudflare.com/ajax/libs/mathjax/2.7.5/MathJax.js?config=TeX-AMS-MML_SVG"></script><script type="text/javascript">if (window.MathJax && window.MathJax.Hub && window.MathJax.Hub.Config) {window.MathJax.Hub.Config({SVG: {font: "STIX-Web"}});}</script>                <script type="text/javascript">window.PlotlyConfig = {MathJaxConfig: 'local'};</script>
        <script charset="utf-8" src="https://cdn.plot.ly/plotly-2.24.1.min.js"></script>                <div id="70192594-3031-44bc-90f6-5dd9d7f85e24" class="plotly-graph-div" style="height:525px; width:100%;"></div>            <script type="text/javascript">                                    window.PLOTLYENV=window.PLOTLYENV || {};                                    if (document.getElementById("70192594-3031-44bc-90f6-5dd9d7f85e24")) {                    Plotly.newPlot(                        "70192594-3031-44bc-90f6-5dd9d7f85e24",                        [{"hovertemplate":"\u003cb\u003e%{hovertext}\u003c\u002fb\u003e\u003cbr\u003e\u003cbr\u003eGDP per capita=%{x}\u003cbr\u003eGDP=%{y}\u003cextra\u003e\u003c\u002fextra\u003e","hovertext":["Aruba","Afghanistan","Angola","Albania","Andorra","United Arab Emirates","Argentina","Armenia","American Samoa","Antigua and Barbuda","Australia","Austria","Azerbaijan","Burundi","Belgium","Benin","Burkina Faso","Bangladesh","Bulgaria","Bahrain","Bahamas, The","Bosnia and Herzegovina","Belarus","Belize","Bermuda","Bolivia","Brazil","Barbados","Brunei Darussalam","Bhutan","Botswana","Central African Republic","Canada","Switzerland","Channel Islands","Chile","Cote d'Ivoire","Cameroon","Congo, Dem. Rep.","Congo, Rep.","Colombia","Comoros","Cabo Verde","Costa Rica","Caribbean small states","Cuba","Curacao","Cayman Islands","Cyprus","Czechia","Germany","Djibouti","Dominica","Denmark","Dominican Republic","Algeria","Ecuador","Egypt, Arab Rep.","Spain","Estonia","Ethiopia","Finland","Fiji","France","Faroe Islands","Micronesia, Fed. Sts.","Gabon","United Kingdom","Georgia","Ghana","Guinea","Gambia, The","Guinea-Bissau","Equatorial Guinea","Greece","Grenada","Greenland","Guatemala","Guam","Guyana","Hong Kong SAR, China","Honduras","Croatia","Haiti","Hungary","Indonesia","Isle of Man","India","Ireland","Iran, Islamic Rep.","Iraq","Iceland","Israel","Italy","Jamaica","Jordan","Japan","Kazakhstan","Kenya","Kyrgyz Republic","Cambodia","Kiribati","St. Kitts and Nevis","Korea, Rep.","Kuwait","Lao PDR","Lebanon","Liberia","Libya","St. Lucia","Liechtenstein","Sri Lanka","Lesotho","Lithuania","Luxembourg","Latvia","Macao SAR, China","Morocco","Monaco","Moldova","Madagascar","Maldives","Mexico","Marshall Islands","North Macedonia","Mali","Malta","Myanmar","Montenegro","Mongolia","Northern Mariana Islands","Mozambique","Mauritania","Mauritius","Malawi","Malaysia","Namibia","New Caledonia","Niger","Nigeria","Nicaragua","Netherlands","Norway","Nepal","Nauru","New Zealand","Oman","Other small states","Pakistan","Panama","Peru","Philippines","Palau","Papua New Guinea","Poland","Puerto Rico","Portugal","Paraguay","West Bank and Gaza","Pacific island small states","French Polynesia","Qatar","Romania","Russian Federation","Rwanda","Saudi Arabia","Sudan","Senegal","Singapore","Solomon Islands","Sierra Leone","El Salvador","San Marino","Somalia","Serbia","Small states","Sao Tome and Principe","Suriname","Slovak Republic","Slovenia","Sweden","Eswatini","Sint Maarten (Dutch part)","Seychelles","Syrian Arab Republic","Turks and Caicos Islands","Chad","Togo","Thailand","Tajikistan","Turkmenistan","Timor-Leste","Tonga","Trinidad and Tobago","Tunisia","Turkiye","Tuvalu","Tanzania","Uganda","Ukraine","Uruguay","Uzbekistan","St. Vincent and the Grenadines","Virgin Islands (U.S.)","Viet Nam","Vanuatu","Samoa","Kosovo","South Africa","Zambia","Zimbabwe",null,null],"legendgroup":"","marker":{"color":"#636efa","symbol":"circle"},"mode":"markers","name":"","orientation":"v","showlegend":false,"x":[24008.12782174769,512.0550982286875,1450.9051121848886,5343.037703995597,37207.23887119092,37629.17416879559,8500.837938505336,4505.8677417569525,15609.77721968434,15224.858589056117,51868.24755678234,48789.49784988721,4229.910649045028,216.8274174808685,45609.00349361105,1240.7331553698177,823.5524108809677,2233.3059012976237,10148.342395443482,23433.187236257385,23998.268019120675,6095.10423658487,6542.864539843605,5185.158069760205,107791.88643513374,3068.812555164562,6923.699911768198,16882.50152301625,27179.352886939847,3181.3397472170277,5875.070605967163,435.4692478000221,43349.67785555699,85897.7843338323,57339.52687135671,13173.784794172267,2349.069882004177,1539.1305451924457,524.6666862114951,2011.2694790098988,5304.289128866414,1519.586779816336,3126.3998587225915,12179.256673519512,8846.49409220248,9499.57250428248,16356.093325454121,83897.50544338897,28281.42578125,22992.87938333477,46749.4762280016,2921.738706232931,7003.469891170425,60836.59241216378,7167.914974328092,3354.1531637159264,5645.199289653324,3571.556906513504,26984.296277027945,23595.243683644083,918.6525940774183,49169.71933884987,4815.689148125404,39179.74425960567,62234.968680204765,3639.412698695877,6680.082664677481,40217.00901169857,4255.742993212536,2176.5762180423885,1073.6593390013934,704.0304628372206,710.2581329782215,6198.942523786549,17617.29150570137,8437.536782312503,54693.07668042647,4609.897257528689,34780.86166246137,6863.074345930166,46109.22999466091,2354.1214338730724,14269.908854933165,1283.1412278593907,16125.609408540726,3895.618152002246,79530.6054839665,1913.2197327875097,85973.08848755006,2746.419483179556,4251.337252728084,58848.41812445999,44846.79159548156,31922.919162618266,4897.264750346529,3998.673138292354,39986.92862870905,9121.636409041561,1936.2507545437425,1256.929226012631,1577.911739916446,1403.9938526269564,18553.657137259837,31721.298914185674,24297.710802095084,2593.355097198469,5599.957522607335,597.5296918930478,7034.658364332583,8951.524765781867,165287.18676651176,3852.3890910219397,917.3563812584418,20381.855782747818,116905.37039685264,18096.202707339373,37474.73459459394,3258.26904296875,182537.38737010874,4376.242493183393,462.4042288183828,7216.816371109468,8894.890650036432,5545.600267412526,5965.450231953645,822.9061368321317,29597.63616285208,1479.6136892536256,7677.371321068167,4041.1741456436735,17302.922136850386,456.58192899510567,1836.2924109859177,9011.042884450235,622.1845912707062,10164.344431072957,4252.041720143527,34877.63563491988,564.8416623175235,2074.6137466742152,1876.6073782367666,52162.570115040624,68340.01810337017,1139.1898920394106,10124.700622094511,41760.59478400051,16707.62300632143,11686.934106994384,1322.3147853955404,13293.333195168774,6063.62692279047,3224.422811217668,14349.316819218784,2446.0846866061465,15816.820402138195,31427.42911367988,22242.406417971975,5353.348064562786,3233.5686383585844,3698.0990600834875,19185.697770290597,52315.66007831166,13047.456656399327,10194.44140625,773.7732608505089,20398.06098709514,608.33251953125,1492.4759029352333,61273.99165944551,2222.462118531731,493.4322405514235,3961.72663347599,45321.48922261609,556.5780660292686,7733.803468937633,10704.407265170259,2155.2658678250846,4796.533313899278,19552.09110959113,25558.429054450586,52837.9039778149,3372.904610197189,29223.069615247525,12020.021064317005,537.0902346114414,20882.261270214112,643.7722156940087,886.6995115081938,7001.785460233889,852.3302295622685,7330.366287930542,1663.5596290754963,4605.970841191367,13705.900228570972,3497.719026589915,8638.739132592988,4674.911402552557,1104.16442871094,846.8811992149166,3751.7373046875,15650.499303244496,1759.3074705367767,8306.360493072014,39411.0452535516,3586.3471762476265,2917.7568490893273,4042.7227515432382,4310.934002005702,5753.066494333694,956.8317289870319,1372.6966743682872,null,null],"xaxis":"x","y":[2558906303.8809776,19955929060.841003,48501561230.00098,15162734205.246202,2891002460.2915344,349473015336.9394,385740508436.9652,12641698583.215239,721000000.0,1410796296.2962961,1330381544909.3044,435049316955.73663,42693000000.0,2649680261.439981,526264230147.3945,15686741893.518715,17725010530.7894,373902197869.1603,70368758395.14104,34621807712.76596,9754600000.0,20226036564.412888,61371755326.2351,2047727810.06777,6887147000.0,36629843806.07815,1476107231194.106,4738800000.0,12005799653.983503,2457604042.763637,14960291541.175995,2326720900.380474,1647598402302.6787,741999406005.6272,9811538461.538462,254258196269.73492,62982768371.62078,40773241177.05051,48716961860.13249,11468608530.20379,270150956772.5698,1225039195.9374163,1821565613.6861308,62395610760.39118,65860096129.81807,107351800000.0,2534327592.49914,5647224988.899956,25227201184.22946,245974558654.04294,3887727161914.4077,3185150981.032067,504214814.8148148,354762748338.6615,78844656298.17764,145743542982.62775,99291124000.0,383817841547.0992,1278128867875.49,31370395572.765846,107657734392.44585,271886077382.10193,4432466237.0958805,2647418691598.4507,3262045883.372933,408000000.0,15314577154.807648,2697806592293.8604,15842922532.720198,70043095503.6675,14177835841.392267,1812170891.1906917,1431758231.6852224,9893816016.146997,188480337285.6052,1043411111.111111,3082884653.245599,77715183063.2054,5886000000.0,5471256594.72422,344943149590.0583,23827859226.88341,57760024673.935875,14508222518.301786,157227094449.07394,1059054842698.482,6684229268.505448,2671595405986.8584,428608687830.2393,239735486745.7037,180924091442.95303,21565767851.143982,413267669231.52216,1897461635591.9119,13812421803.408361,43700383098.59155,5048789595589.434,171082365861.4229,100657505750.545,8270468614.240511,25872797891.766376,177553274.58476278,883933333.3333333,1644312831906.1692,105948807280.7307,18981800705.079376,31712128253.796097,3039982500.0,46808208746.08388,1604444444.4444444,6405870210.32293,84440516486.1099,2067813018.9946537,56964942999.365135,73699366700.21344,34390910338.9604,25343525935.835773,121353645057.14369,6739645416.479156,11531967881.062355,13051441203.947355,3712604580.320812,1120741118380.2666,240751144.40918,12363580534.68112,17465392764.370636,15252609039.074888,79045695084.50691,4769996866.007579,13312981429.08905,858000000.0,14235420505.290434,8260752385.230893,11408106446.31438,12056108778.31254,337456163961.2112,10583748541.525812,9454629467.914082,13744653102.99452,432198898221.9667,12678162403.59288,909793466661.4811,367633418886.62726,33433659223.63493,124685688.1610939,212569779569.51938,75909397659.29779,378440036056.0108,300425609817.9812,57086836900.0,201947615138.56744,361751145451.59674,257885921.875,23848445103.92275,599442783598.0636,103130900000.0,229031860520.77728,35432178068.18139,15531700000.0,9492350931.304438,5792545870.806137,144411363345.27032,251362514349.69714,1493075894362.1426,10172303393.061218,734271183944.9894,27034593750.0,24530513037.751846,348392090695.2169,1536145814.1700656,4062906265.7332044,24930080000.0,1541247883.9935052,9204140383.175072,53356484591.43781,453792483117.1333,471229484.6071443,2911807496.2022653,106731482855.49602,53734526854.22894,547054174235.87585,3982236692.552362,1236428075.4211228,1183515314.034781,11156757922.038454,924583000.0,10715396042.334282,7486031561.868847,500457264955.7628,8133963813.070248,45818000000.0,2162619200.0,484796854.9187562,20807571314.304337,42538289933.21618,720338498174.7438,51746594.31485426,66068737786.06392,37605430214.351875,156617722013.3422,53666908053.76546,60224701296.78847,869111111.111111,4189000000.0,346615738537.7963,909421043.508407,868898358.2664367,7717145217.812473,338291396025.9558,18110638269.223778,21509698406.66182,null,null],"yaxis":"y","type":"scatter"}],                        {"template":{"data":{"histogram2dcontour":[{"type":"histogram2dcontour","colorbar":{"outlinewidth":0,"ticks":""},"colorscale":[[0.0,"#0d0887"],[0.1111111111111111,"#46039f"],[0.2222222222222222,"#7201a8"],[0.3333333333333333,"#9c179e"],[0.4444444444444444,"#bd3786"],[0.5555555555555556,"#d8576b"],[0.6666666666666666,"#ed7953"],[0.7777777777777778,"#fb9f3a"],[0.8888888888888888,"#fdca26"],[1.0,"#f0f921"]]}],"choropleth":[{"type":"choropleth","colorbar":{"outlinewidth":0,"ticks":""}}],"histogram2d":[{"type":"histogram2d","colorbar":{"outlinewidth":0,"ticks":""},"colorscale":[[0.0,"#0d0887"],[0.1111111111111111,"#46039f"],[0.2222222222222222,"#7201a8"],[0.3333333333333333,"#9c179e"],[0.4444444444444444,"#bd3786"],[0.5555555555555556,"#d8576b"],[0.6666666666666666,"#ed7953"],[0.7777777777777778,"#fb9f3a"],[0.8888888888888888,"#fdca26"],[1.0,"#f0f921"]]}],"heatmap":[{"type":"heatmap","colorbar":{"outlinewidth":0,"ticks":""},"colorscale":[[0.0,"#0d0887"],[0.1111111111111111,"#46039f"],[0.2222222222222222,"#7201a8"],[0.3333333333333333,"#9c179e"],[0.4444444444444444,"#bd3786"],[0.5555555555555556,"#d8576b"],[0.6666666666666666,"#ed7953"],[0.7777777777777778,"#fb9f3a"],[0.8888888888888888,"#fdca26"],[1.0,"#f0f921"]]}],"heatmapgl":[{"type":"heatmapgl","colorbar":{"outlinewidth":0,"ticks":""},"colorscale":[[0.0,"#0d0887"],[0.1111111111111111,"#46039f"],[0.2222222222222222,"#7201a8"],[0.3333333333333333,"#9c179e"],[0.4444444444444444,"#bd3786"],[0.5555555555555556,"#d8576b"],[0.6666666666666666,"#ed7953"],[0.7777777777777778,"#fb9f3a"],[0.8888888888888888,"#fdca26"],[1.0,"#f0f921"]]}],"contourcarpet":[{"type":"contourcarpet","colorbar":{"outlinewidth":0,"ticks":""}}],"contour":[{"type":"contour","colorbar":{"outlinewidth":0,"ticks":""},"colorscale":[[0.0,"#0d0887"],[0.1111111111111111,"#46039f"],[0.2222222222222222,"#7201a8"],[0.3333333333333333,"#9c179e"],[0.4444444444444444,"#bd3786"],[0.5555555555555556,"#d8576b"],[0.6666666666666666,"#ed7953"],[0.7777777777777778,"#fb9f3a"],[0.8888888888888888,"#fdca26"],[1.0,"#f0f921"]]}],"surface":[{"type":"surface","colorbar":{"outlinewidth":0,"ticks":""},"colorscale":[[0.0,"#0d0887"],[0.1111111111111111,"#46039f"],[0.2222222222222222,"#7201a8"],[0.3333333333333333,"#9c179e"],[0.4444444444444444,"#bd3786"],[0.5555555555555556,"#d8576b"],[0.6666666666666666,"#ed7953"],[0.7777777777777778,"#fb9f3a"],[0.8888888888888888,"#fdca26"],[1.0,"#f0f921"]]}],"mesh3d":[{"type":"mesh3d","colorbar":{"outlinewidth":0,"ticks":""}}],"scatter":[{"fillpattern":{"fillmode":"overlay","size":10,"solidity":0.2},"type":"scatter"}],"parcoords":[{"type":"parcoords","line":{"colorbar":{"outlinewidth":0,"ticks":""}}}],"scatterpolargl":[{"type":"scatterpolargl","marker":{"colorbar":{"outlinewidth":0,"ticks":""}}}],"bar":[{"error_x":{"color":"#2a3f5f"},"error_y":{"color":"#2a3f5f"},"marker":{"line":{"color":"#E5ECF6","width":0.5},"pattern":{"fillmode":"overlay","size":10,"solidity":0.2}},"type":"bar"}],"scattergeo":[{"type":"scattergeo","marker":{"colorbar":{"outlinewidth":0,"ticks":""}}}],"scatterpolar":[{"type":"scatterpolar","marker":{"colorbar":{"outlinewidth":0,"ticks":""}}}],"histogram":[{"marker":{"pattern":{"fillmode":"overlay","size":10,"solidity":0.2}},"type":"histogram"}],"scattergl":[{"type":"scattergl","marker":{"colorbar":{"outlinewidth":0,"ticks":""}}}],"scatter3d":[{"type":"scatter3d","line":{"colorbar":{"outlinewidth":0,"ticks":""}},"marker":{"colorbar":{"outlinewidth":0,"ticks":""}}}],"scattermapbox":[{"type":"scattermapbox","marker":{"colorbar":{"outlinewidth":0,"ticks":""}}}],"scatterternary":[{"type":"scatterternary","marker":{"colorbar":{"outlinewidth":0,"ticks":""}}}],"scattercarpet":[{"type":"scattercarpet","marker":{"colorbar":{"outlinewidth":0,"ticks":""}}}],"carpet":[{"aaxis":{"endlinecolor":"#2a3f5f","gridcolor":"white","linecolor":"white","minorgridcolor":"white","startlinecolor":"#2a3f5f"},"baxis":{"endlinecolor":"#2a3f5f","gridcolor":"white","linecolor":"white","minorgridcolor":"white","startlinecolor":"#2a3f5f"},"type":"carpet"}],"table":[{"cells":{"fill":{"color":"#EBF0F8"},"line":{"color":"white"}},"header":{"fill":{"color":"#C8D4E3"},"line":{"color":"white"}},"type":"table"}],"barpolar":[{"marker":{"line":{"color":"#E5ECF6","width":0.5},"pattern":{"fillmode":"overlay","size":10,"solidity":0.2}},"type":"barpolar"}],"pie":[{"automargin":true,"type":"pie"}]},"layout":{"autotypenumbers":"strict","colorway":["#636efa","#EF553B","#00cc96","#ab63fa","#FFA15A","#19d3f3","#FF6692","#B6E880","#FF97FF","#FECB52"],"font":{"color":"#2a3f5f"},"hovermode":"closest","hoverlabel":{"align":"left"},"paper_bgcolor":"white","plot_bgcolor":"#E5ECF6","polar":{"bgcolor":"#E5ECF6","angularaxis":{"gridcolor":"white","linecolor":"white","ticks":""},"radialaxis":{"gridcolor":"white","linecolor":"white","ticks":""}},"ternary":{"bgcolor":"#E5ECF6","aaxis":{"gridcolor":"white","linecolor":"white","ticks":""},"baxis":{"gridcolor":"white","linecolor":"white","ticks":""},"caxis":{"gridcolor":"white","linecolor":"white","ticks":""}},"coloraxis":{"colorbar":{"outlinewidth":0,"ticks":""}},"colorscale":{"sequential":[[0.0,"#0d0887"],[0.1111111111111111,"#46039f"],[0.2222222222222222,"#7201a8"],[0.3333333333333333,"#9c179e"],[0.4444444444444444,"#bd3786"],[0.5555555555555556,"#d8576b"],[0.6666666666666666,"#ed7953"],[0.7777777777777778,"#fb9f3a"],[0.8888888888888888,"#fdca26"],[1.0,"#f0f921"]],"sequentialminus":[[0.0,"#0d0887"],[0.1111111111111111,"#46039f"],[0.2222222222222222,"#7201a8"],[0.3333333333333333,"#9c179e"],[0.4444444444444444,"#bd3786"],[0.5555555555555556,"#d8576b"],[0.6666666666666666,"#ed7953"],[0.7777777777777778,"#fb9f3a"],[0.8888888888888888,"#fdca26"],[1.0,"#f0f921"]],"diverging":[[0,"#8e0152"],[0.1,"#c51b7d"],[0.2,"#de77ae"],[0.3,"#f1b6da"],[0.4,"#fde0ef"],[0.5,"#f7f7f7"],[0.6,"#e6f5d0"],[0.7,"#b8e186"],[0.8,"#7fbc41"],[0.9,"#4d9221"],[1,"#276419"]]},"xaxis":{"gridcolor":"white","linecolor":"white","ticks":"","title":{"standoff":15},"zerolinecolor":"white","automargin":true,"zerolinewidth":2},"yaxis":{"gridcolor":"white","linecolor":"white","ticks":"","title":{"standoff":15},"zerolinecolor":"white","automargin":true,"zerolinewidth":2},"scene":{"xaxis":{"backgroundcolor":"#E5ECF6","gridcolor":"white","linecolor":"white","showbackground":true,"ticks":"","zerolinecolor":"white","gridwidth":2},"yaxis":{"backgroundcolor":"#E5ECF6","gridcolor":"white","linecolor":"white","showbackground":true,"ticks":"","zerolinecolor":"white","gridwidth":2},"zaxis":{"backgroundcolor":"#E5ECF6","gridcolor":"white","linecolor":"white","showbackground":true,"ticks":"","zerolinecolor":"white","gridwidth":2}},"shapedefaults":{"line":{"color":"#2a3f5f"}},"annotationdefaults":{"arrowcolor":"#2a3f5f","arrowhead":0,"arrowwidth":1},"geo":{"bgcolor":"white","landcolor":"#E5ECF6","subunitcolor":"white","showland":true,"showlakes":true,"lakecolor":"white"},"title":{"x":0.05},"mapbox":{"style":"light"}}},"xaxis":{"anchor":"y","domain":[0.0,1.0],"title":{"text":"GDP per capita ($ thousands)"}},"yaxis":{"anchor":"x","domain":[0.0,1.0],"title":{"text":"GDP ($ trillians)"}},"legend":{"tracegroupgap":0},"title":{"text":"GDP per capita vs GDP"}},                        {"responsive": true}                    ).then(function(){

var gd = document.getElementById('70192594-3031-44bc-90f6-5dd9d7f85e24');
var x = new MutationObserver(function (mutations, observer) {{
        var display = window.getComputedStyle(gd).display;
        if (!display || display === 'none') {{
            console.log([gd, 'removed!']);
            Plotly.purge(gd);
            observer.disconnect();
        }}
}});

// Listen for the removal of the full notebook cells
var notebookContainer = gd.closest('#notebook-container');
if (notebookContainer) {{
    x.observe(notebookContainer, {childList: true});
}}

// Listen for the clearing of the current output cell
var outputEl = gd.closest('.output');
if (outputEl) {{
    x.observe(outputEl, {childList: true});
}}

                        })                };                            </script>        </div>
</body>
</html>


Source: The World Bank

From this graph, we can see that:
- A country may have a high total GDP due to its large size but a moderate GDP per capita, for example India,
- Similarly, a country may have a low overal GDP due limited size but a high GDP per capital level driven by high production level, for example Liechtenstein and Monaco

## 1.3 GDP: Ways of Calculation

GDP can be calculated using three main methods: the Expenditure Method, the Income Method, and the Output Method. Each approach focuses on a different aspect of the economy's total output and income. However, in theory, all three should arrive at the same GDP figure, reflecting the circular flow of income in the economy.

### 1.3.1 Expenditure Method

The expenditure method calculates GDP by summing up all expenditures made on final goods and services, i.e. ones that will not be sold again as part of other goods or services, over a specific period. The formula is represented as: `GDP = C + I + G + (X - M)`

where:
- `C` stands for consumption by households,
- `I` represents investment by firms,
- `G` is government spending,
- `X` represents exports, and
- `M` stands for imports (`X - M` is net exports).



### 1.3.2 Income Method

The income method approaches GDP calculation by summing all incomes generated by factors of production in the economy, including wages, interest, rent, and profits. The formula can be presented as: `GDP = Total National Income + Sales Taxes + Depreciation + Net Foreign Factor Income`

where
- `Total National Income` is the sum of wages, interest, rent, and profits earned,
- `Sales Taxes` are taxes imposed on sales of goods and services,
- `Depreciation` is the wear and loose of value on physical assets over time,
- `Net Foreign Factor Income` is the difference between the income a nation receive from foreign countries – payments to made foreign entities


### 1.3.3 Output/Production Method

This method calculates GDP by adding up the value added at each stage of production across all industries. The value added at each stage is the sale price minus the cost of inputs. For example, in the production of bread:
- The farmer grows wheat and sells it at a value added of 0.1.
- The mill buys the wheat and produces flour, adding value of 0.4.
- The baker uses the flour to make bread, adding value of 1.0.
- The store sells the bread, adding a final value of 1.5.

The total GDP using this method would be the sum of all value added, which in this case is 0.1+0.4+1.0+1.5 = 3.0.

The follow table illustrates this method in a clearer way:


```python
data = {
    'Stage': ['Farmer', 'Mill', 'Baker', 'Store'],
    'Costs': [0, 0.1, 0.5, 1.5],
    'Sale Price': [0.1, 0.5, 1.5, 3.0],
    'Value Added': [0.1, 0.4, 1.0, 1.5]
}

df = pd.DataFrame(data)


total_value_added = df['Value Added'].sum()

total_df = pd.DataFrame([{'Stage': 'Total', 'Costs': '-', 'Sale Price': '-', 'Value Added': total_value_added}])

df_final = pd.concat([df, total_df], ignore_index=True)

print(df_final.to_string(index=False))

```

     Stage Costs Sale Price  Value Added
    Farmer   0.0        0.1          0.1
      Mill   0.1        0.5          0.4
     Baker   0.5        1.5          1.0
     Store   1.5        3.0          1.5
     Total     -          -          3.0


## 1.4 Expenditure Method: Components of GDP vs. GDP Per Capita as Correlations

The collection and preprocessing of the csv files ("gdp_components.csv" and "gdp_components_2.csv") can be found here.


```python
gdp_components = pd.read_csv('/content/drive/MyDrive/gdp_components_income.csv')
```

#### 1.4.1 Components of GDP for User-Selected Country


```python
def components_of_gdp(country):
    df = gdp_components[gdp_components['Country Name'] == country].copy()

    if df['Consumer Expenditure (as % of GDP)'].notnull().any() and \
       df['Government Expenditure (as % of GDP)'].notnull().any() and \
       df['Investment Expenditure (as % of GDP)'].notnull().any() and \
       df['Net Exports Expenditure (as % of GDP)'].notnull().any():

        df['Total Expenditure'] = df['Consumer Expenditure (as % of GDP)'] + \
                                  df['Government Expenditure (as % of GDP)'] + \
                                  df['Investment Expenditure (as % of GDP)'] + \
                                  df['Net Exports Expenditure (as % of GDP)']

        plt.figure(figsize=(10, 6))

        # Plot the stacked bar chart
        plt.bar(df['Year'], df['Consumer Expenditure (as % of GDP)'], label='Consumer Expenditure')
        plt.bar(df['Year'], df['Government Expenditure (as % of GDP)'], bottom=df['Consumer Expenditure (as % of GDP)'],
                label='Government Expenditure')
        plt.bar(df['Year'], df['Investment Expenditure (as % of GDP)'],
                bottom=df['Consumer Expenditure (as % of GDP)'] + df['Government Expenditure (as % of GDP)'],
                label='Investment Expenditure')

        # Plot the negative bars as Trade Deficit
        net_exports = df['Net Exports Expenditure (as % of GDP)']
        plt.bar(df['Year'], net_exports.where(net_exports >= 0, 0),
                bottom=df['Consumer Expenditure (as % of GDP)'] + df['Government Expenditure (as % of GDP)'] +
                       df['Investment Expenditure (as % of GDP)'],
                label='Trade Surplus')

        # Plot the positive bars as Trade Surplus
        plt.bar(df['Year'], net_exports.where(net_exports < 0, 0),
                bottom=df['Consumer Expenditure (as % of GDP)'] + df['Government Expenditure (as % of GDP)'] +
                       df['Investment Expenditure (as % of GDP)'] + net_exports.where(net_exports < 0, 0),
                label='Trade Deficit')

        plt.xlabel('Year')
        plt.ylabel('Components of GDP (as % of GDP)')
        plt.title(f'Components of GDP - {country}')
        plt.legend(loc='upper left')

        #Set x-ticks
        min_year = df['Year'].min()
        max_year = df['Year'].max()
        x_ticks = range(min_year, max_year + 1, 5)
        plt.xticks(x_ticks, [str(year) for year in x_ticks], rotation=45)

        plt.legend(loc='upper left', bbox_to_anchor=(1, 1))

        plt.show()
```


```python
components_of_gdp(country='United States')
```


    
![png](Why_GDP_lecture_files/Why_GDP_lecture_22_0.png)
    


#### 1.4.1 Components of GDP vs. GDP Per Capita as Trends for User-Selected Country


```python
def components_of_gdp(country):
    df = gdp_components[gdp_components['Country Name'] == country].copy()

    if df['Consumer Expenditure (as % of GDP)'].notnull().any() and \
       df['Government Expenditure (as % of GDP)'].notnull().any() and \
       df['Investment Expenditure (as % of GDP)'].notnull().any() and \
       df['Net Exports Expenditure (as % of GDP)'].notnull().any():

        fig, axs = plt.subplots(1, 2, figsize=(14, 6))

        # Plot the line chart on the left for percentage difference relative to the first non-empty row
        axs[0].plot(df['Year'], df['Consumer Expenditure (as % of GDP) % Difference (First Non-Empty)'], label='Consumer Expenditure', marker='o')
        axs[0].plot(df['Year'], df['Government Expenditure (as % of GDP) % Difference (First Non-Empty)'], label='Government Expenditure', marker='o')
        axs[0].plot(df['Year'], df['Investment Expenditure (as % of GDP) % Difference (First Non-Empty)'], label='Investment Expenditure', marker='o')
        axs[0].plot(df['Year'], df['Net Exports Expenditure (as % of GDP) % Difference (First Non-Empty)'], label='Net Exports Expenditure', marker='o')
        axs[0].set_xlabel('Year')
        axs[0].set_ylabel('Percentage Difference (as % of GDP)')
        axs[0].set_title(f'Percentage Difference Relative to First Non-Empty Row - {country}')
        axs[0].legend()

        # Plot the line chart on the right for percentage difference relative to the previous year
        axs[1].plot(df['Year'], df['Consumer Expenditure (as % of GDP) % Difference (Last Year)'], label='Consumer Expenditure', marker='o')
        axs[1].plot(df['Year'], df['Government Expenditure (as % of GDP) % Difference (Last Year)'], label='Government Expenditure', marker='o')
        axs[1].plot(df['Year'], df['Investment Expenditure (as % of GDP) % Difference (Last Year)'], label='Investment Expenditure', marker='o')
        axs[1].plot(df['Year'], df['Net Exports Expenditure (as % of GDP) % Difference (Last Year)'], label='Net Exports Expenditure', marker='o')
        axs[1].set_xlabel('Year')
        axs[1].set_ylabel('Percentage Difference (as % of GDP)')
        axs[1].set_title(f'Percentage Difference Relative to Previous Year - {country}')
        axs[1].legend()

        plt.tight_layout()
        plt.show()
```


```python
components_of_gdp(country='United States')
```


    
![png](Why_GDP_lecture_files/Why_GDP_lecture_25_0.png)
    


#### 1.4.2 Components of GDP vs. GDP Per Capita as Correlations for User-Selected Year


```python
def plot_gdp_component_scatter(year):
    # Filter the dataframe for the specific year
    df_year = gdp_components[gdp_components['Year'] == year]

    # Select the relevant columns for scatter plots
    df_scatter = df_year[['Consumer Expenditure (as % of GDP)',
                          'Government Expenditure (as % of GDP)',
                          'Investment Expenditure (as % of GDP)',
                          'Net Exports Expenditure (as % of GDP)',
                          'GDP per capita',
                          'Country Name',
                          'Income Level']]

    # Create a scatter plot for each GDP component
    scatter_plots = []
    for column in ['Consumer Expenditure (as % of GDP)',
                   'Government Expenditure (as % of GDP)',
                   'Investment Expenditure (as % of GDP)',
                   'Net Exports Expenditure (as % of GDP)']:
        fig = px.scatter(df_scatter, x='GDP per capita', y =column, color='Income Level',
                         hover_data=['Country Name'], title=f'{column} vs GDP per capita ({year})')
        scatter_plots.append(fig)

    # Display the scatter plots
    for fig in scatter_plots:
        fig.show()
```


```python
plot_gdp_component_scatter(2018)
```


<html>
<head><meta charset="utf-8" /></head>
<body>
    <div>            <script src="https://cdnjs.cloudflare.com/ajax/libs/mathjax/2.7.5/MathJax.js?config=TeX-AMS-MML_SVG"></script><script type="text/javascript">if (window.MathJax && window.MathJax.Hub && window.MathJax.Hub.Config) {window.MathJax.Hub.Config({SVG: {font: "STIX-Web"}});}</script>                <script type="text/javascript">window.PlotlyConfig = {MathJaxConfig: 'local'};</script>
        <script charset="utf-8" src="https://cdn.plot.ly/plotly-2.24.1.min.js"></script>                <div id="5cc5557e-2f6e-4ae3-872c-fb9189f73d51" class="plotly-graph-div" style="height:525px; width:100%;"></div>            <script type="text/javascript">                                    window.PLOTLYENV=window.PLOTLYENV || {};                                    if (document.getElementById("5cc5557e-2f6e-4ae3-872c-fb9189f73d51")) {                    Plotly.newPlot(                        "5cc5557e-2f6e-4ae3-872c-fb9189f73d51",                        [{"customdata":[["Afghanistan"],["Benin"],["Burkina Faso"],["Burundi"],["Central African Republic"],["Chad"],["Ethiopia"],["Guinea"],["Guinea-Bissau"],["Haiti"],["Liberia"],["Madagascar"],["Malawi"],["Mali"],["Mozambique"],["Nepal"],["Niger"],["Rwanda"],["Sierra Leone"],["Syrian Arab Republic"],["Tajikistan"],["Togo"],["Uganda"]],"hovertemplate":"Income Level=Low income\u003cbr\u003eGDP per capita=%{x}\u003cbr\u003eConsumer Expenditure (as % of GDP)=%{y}\u003cbr\u003eCountry Name=%{customdata[0]}\u003cextra\u003e\u003c\u002fextra\u003e","legendgroup":"Low income","marker":{"color":"#636efa","symbol":"circle"},"mode":"markers","name":"Low income","orientation":"v","showlegend":true,"x":[null,1.3045363065075943,0.9423917056106909,0.2997825084701306,0.416426157737857,0.7634076046419629,0.8424703094577008,1.1541776261411962,0.9539180675900872,1.6420406955759412,null,0.6187352659533052,null,1.1801675454169258,null,1.034949667840119,0.6888681585022614,0.9335541169168238,0.6955406414196662,1.472296369124743,0.9669804348483436,0.9618428718740492,0.8312195928096361],"xaxis":"x","y":[null,73.55974298479953,70.78393171278562,82.50117506990422,94.13482371519018,78.14017780742971,71.32160279578855,77.14130261420665,75.89371728604851,99.31700177514485,null,74.13969033676709,null,79.42890509819043,null,91.73368148768712,74.8521339851116,79.08709394907532,99.4973069120881,96.40530564735371,81.78780722929542,80.2428229287185,75.74208581635477],"yaxis":"y","type":"scatter"},{"customdata":[["Albania"],["Algeria"],["Argentina"],["Armenia"],["Azerbaijan"],["Belarus"],["Bosnia and Herzegovina"],["Botswana"],["Brazil"],["Bulgaria"],["China"],["Colombia"],["Costa Rica"],["Cuba"],["Dominica"],["Dominican Republic"],["Ecuador"],["Equatorial Guinea"],["Gabon"],["Georgia"],["Guatemala"],["Iraq"],["Jamaica"],["Jordan"],["Kazakhstan"],["Lebanon"],["Libya"],["Malaysia"],["Mauritius"],["Mexico"],["Montenegro"],["Namibia"],["Paraguay"],["Peru"],["Romania"],["Russian Federation"],["Serbia"],["South Africa"],["Sri Lanka"],["Thailand"],["Turkmenistan"]],"hovertemplate":"Income Level=Upper middle income\u003cbr\u003eGDP per capita=%{x}\u003cbr\u003eConsumer Expenditure (as % of GDP)=%{y}\u003cbr\u003eCountry Name=%{customdata[0]}\u003cextra\u003e\u003c\u002fextra\u003e","legendgroup":"Upper middle income","marker":{"color":"#EF553B","symbol":"circle"},"mode":"markers","name":"Upper middle income","orientation":"v","showlegend":true,"x":[5.5365187015336,4.656358067756523,13.43816667529076,4.53545424780213,5.482806843127045,7.105367136361758,6.2605263652189125,9.71505031393233,10.876767251472902,10.55388901479824,11.543151777277965,8.017000102028279,14.503687986721852,11.65152806719012,null,9.131555105147369,7.4030035575351025,20.316898888639383,8.952159065170372,3.941293671607263,4.724665386900773,5.9819376990495545,6.677127903147384,5.365306694425017,9.947973864860291,8.165175918858733,15.624896937081882,12.934681764340768,12.284721444129024,11.4446752397259,10.385329667663044,6.82081880482101,6.158991030732602,7.993207106169597,14.542213099406409,13.175549950866124,8.1508594160437,8.721878107745141,4.404444202132617,8.470822302692627,null],"xaxis":"x","y":[80.79632295733548,53.66372325737295,74.51380129954799,86.26044032823974,57.54122788483993,61.44316295388808,77.10748863022101,56.226819021408325,70.4864944750285,66.91674106149394,47.83675411822726,72.3577592216358,69.89514825233087,66.43376079924029,null,71.41263076010772,65.52522776423537,58.133666960690775,44.48049092694834,74.85598867436354,87.261398994732,56.44244993758411,78.9531854665251,82.77421026866703,59.44450903517391,90.95342312782778,50.94007627166172,61.80967583644437,76.51190800636502,70.96449524053683,79.37272155737178,74.64060940856083,69.53978951531612,68.27247662910908,69.78189634678766,58.46129931637557,75.46219106810717,69.9565257792057,67.98022595652684,57.65037072345407,null],"yaxis":"y","type":"scatter"},{"customdata":[["Angola"],["Bangladesh"],["Cabo Verde"],["Cambodia"],["Cameroon"],["Comoros"],["Djibouti"],["El Salvador"],["Ghana"],["Honduras"],["India"],["Indonesia"],["Kenya"],["Lesotho"],["Mauritania"],["Mongolia"],["Morocco"],["Myanmar"],["Nicaragua"],["Nigeria"],["Pakistan"],["Philippines"],["Senegal"],["Tunisia"],["Ukraine"],["Uzbekistan"],["Zambia"],["Zimbabwe"]],"hovertemplate":"Income Level=Lower middle income\u003cbr\u003eGDP per capita=%{x}\u003cbr\u003eConsumer Expenditure (as % of GDP)=%{y}\u003cbr\u003eCountry Name=%{customdata[0]}\u003cextra\u003e\u003c\u002fextra\u003e","legendgroup":"Lower middle income","marker":{"color":"#00cc96","symbol":"circle"},"mode":"markers","name":"Lower middle income","orientation":"v","showlegend":true,"x":[3.8535590703151663,1.9989045745475744,null,1.518061006773532,1.6965255969857094,1.5942202502252845,4.846573798428586,4.695081976480254,2.575051818847171,2.9848769472429204,2.2203459660510787,4.267266456476381,2.0024417354026625,1.8573921671666676,1.935872794284197,4.253117361651591,4.079512244786143,null,2.4211697513353463,null,1.769331600016486,3.470580341600621,1.5473027586138857,4.277700999187144,3.568588701314224,1.807796971100641,1.624343950010044,2.5992548853101973],"xaxis":"x","y":[60.87078338435467,70.60765366156915,null,74.5799798142458,74.66769421691549,92.90686118109572,57.37369084663544,86.49853026411768,74.43100950224157,84.26328787689343,65.74815462174193,62.12336209547987,80.17712476241262,86.48421627774434,69.88893006639464,70.53518320518216,68.1164335939598,null,75.46011478132179,null,85.46034730280124,75.40470517158265,76.03723789378131,78.18868452985068,75.22364634367585,73.41000245613816,54.14539987370416,82.1016893865684],"yaxis":"y","type":"scatter"},{"customdata":[["Australia"],["Austria"],["Bahrain"],["Barbados"],["Belgium"],["Canada"],["Chile"],["Croatia"],["Cyprus"],["Denmark"],["Estonia"],["Finland"],["France"],["Germany"],["Greece"],["Hungary"],["Iceland"],["Ireland"],["Israel"],["Italy"],["Japan"],["Kuwait"],["Latvia"],["Lithuania"],["Luxembourg"],["Malta"],["Netherlands"],["New Zealand"],["Norway"],["Oman"],["Panama"],["Poland"],["Portugal"],["Puerto Rico"],["Qatar"],["Saudi Arabia"],["Seychelles"],["Singapore"],["Slovenia"],["Spain"],["Sweden"],["Switzerland"],["Trinidad and Tobago"],["United Arab Emirates"],["United Kingdom"],["United States"],["Uruguay"]],"hovertemplate":"Income Level=High income\u003cbr\u003eGDP per capita=%{x}\u003cbr\u003eConsumer Expenditure (as % of GDP)=%{y}\u003cbr\u003eCountry Name=%{customdata[0]}\u003cextra\u003e\u003c\u002fextra\u003e","legendgroup":"High income","marker":{"color":"#ab63fa","symbol":"circle"},"mode":"markers","name":"High income","orientation":"v","showlegend":true,"x":[68.92380225582335,60.22665665211098,26.36956722236935,19.824924692373035,57.68378367988274,55.63555110471394,18.01217512805355,19.065584831786992,28.55178058696604,76.00629771784118,28.01822462101277,60.83959658667786,50.926428954480215,56.2160279207692,23.42278611341433,19.322318189192536,92.26640606413878,88.76210929938102,53.980370920364,40.90619262622918,47.74192480394642,null,20.86504572808823,22.45774398827238,135.03389024507197,36.30902284819293,65.68873805572721,51.55460942711251,98.64377489854924,23.312104382606304,null,17.636314749583878,27.548883136669264,33.667706137206466,null,30.01028424970493,20.49769509749656,66.8551394051294,30.48046667854283,35.31277554830795,68.3609054340486,93.86419816759827,null,46.363776580562345,50.915604206352434,71.19717335877542,null],"xaxis":"x","y":[62.68170286584562,60.55055092402222,51.62459563412212,76.11119715037943,61.73933728750166,65.48629379097248,67.64619717028349,65.74823266952596,69.54955979219602,57.74242832319635,58.58407616095509,62.433616639391865,63.08173567923478,60.47508601809907,75.58097176535941,58.61591204431178,60.08792533048837,38.28500044759115,61.77811034083993,66.89449106860174,62.36974258187442,null,66.3453475388583,66.54462860549685,43.44213761109604,53.493600750454085,55.31361047990468,64.61110541071939,55.24849109415295,46.82182329899487,null,66.562634634402,69.91431215189372,66.0007663007956,null,51.976559280276966,47.19390850250504,41.80526154400421,60.417688042266434,65.27411033868434,57.299622691936094,56.841061159905095,null,47.4486535394886,70.2974397546021,71.85631780024259,null],"yaxis":"y","type":"scatter"}],                        {"template":{"data":{"histogram2dcontour":[{"type":"histogram2dcontour","colorbar":{"outlinewidth":0,"ticks":""},"colorscale":[[0.0,"#0d0887"],[0.1111111111111111,"#46039f"],[0.2222222222222222,"#7201a8"],[0.3333333333333333,"#9c179e"],[0.4444444444444444,"#bd3786"],[0.5555555555555556,"#d8576b"],[0.6666666666666666,"#ed7953"],[0.7777777777777778,"#fb9f3a"],[0.8888888888888888,"#fdca26"],[1.0,"#f0f921"]]}],"choropleth":[{"type":"choropleth","colorbar":{"outlinewidth":0,"ticks":""}}],"histogram2d":[{"type":"histogram2d","colorbar":{"outlinewidth":0,"ticks":""},"colorscale":[[0.0,"#0d0887"],[0.1111111111111111,"#46039f"],[0.2222222222222222,"#7201a8"],[0.3333333333333333,"#9c179e"],[0.4444444444444444,"#bd3786"],[0.5555555555555556,"#d8576b"],[0.6666666666666666,"#ed7953"],[0.7777777777777778,"#fb9f3a"],[0.8888888888888888,"#fdca26"],[1.0,"#f0f921"]]}],"heatmap":[{"type":"heatmap","colorbar":{"outlinewidth":0,"ticks":""},"colorscale":[[0.0,"#0d0887"],[0.1111111111111111,"#46039f"],[0.2222222222222222,"#7201a8"],[0.3333333333333333,"#9c179e"],[0.4444444444444444,"#bd3786"],[0.5555555555555556,"#d8576b"],[0.6666666666666666,"#ed7953"],[0.7777777777777778,"#fb9f3a"],[0.8888888888888888,"#fdca26"],[1.0,"#f0f921"]]}],"heatmapgl":[{"type":"heatmapgl","colorbar":{"outlinewidth":0,"ticks":""},"colorscale":[[0.0,"#0d0887"],[0.1111111111111111,"#46039f"],[0.2222222222222222,"#7201a8"],[0.3333333333333333,"#9c179e"],[0.4444444444444444,"#bd3786"],[0.5555555555555556,"#d8576b"],[0.6666666666666666,"#ed7953"],[0.7777777777777778,"#fb9f3a"],[0.8888888888888888,"#fdca26"],[1.0,"#f0f921"]]}],"contourcarpet":[{"type":"contourcarpet","colorbar":{"outlinewidth":0,"ticks":""}}],"contour":[{"type":"contour","colorbar":{"outlinewidth":0,"ticks":""},"colorscale":[[0.0,"#0d0887"],[0.1111111111111111,"#46039f"],[0.2222222222222222,"#7201a8"],[0.3333333333333333,"#9c179e"],[0.4444444444444444,"#bd3786"],[0.5555555555555556,"#d8576b"],[0.6666666666666666,"#ed7953"],[0.7777777777777778,"#fb9f3a"],[0.8888888888888888,"#fdca26"],[1.0,"#f0f921"]]}],"surface":[{"type":"surface","colorbar":{"outlinewidth":0,"ticks":""},"colorscale":[[0.0,"#0d0887"],[0.1111111111111111,"#46039f"],[0.2222222222222222,"#7201a8"],[0.3333333333333333,"#9c179e"],[0.4444444444444444,"#bd3786"],[0.5555555555555556,"#d8576b"],[0.6666666666666666,"#ed7953"],[0.7777777777777778,"#fb9f3a"],[0.8888888888888888,"#fdca26"],[1.0,"#f0f921"]]}],"mesh3d":[{"type":"mesh3d","colorbar":{"outlinewidth":0,"ticks":""}}],"scatter":[{"fillpattern":{"fillmode":"overlay","size":10,"solidity":0.2},"type":"scatter"}],"parcoords":[{"type":"parcoords","line":{"colorbar":{"outlinewidth":0,"ticks":""}}}],"scatterpolargl":[{"type":"scatterpolargl","marker":{"colorbar":{"outlinewidth":0,"ticks":""}}}],"bar":[{"error_x":{"color":"#2a3f5f"},"error_y":{"color":"#2a3f5f"},"marker":{"line":{"color":"#E5ECF6","width":0.5},"pattern":{"fillmode":"overlay","size":10,"solidity":0.2}},"type":"bar"}],"scattergeo":[{"type":"scattergeo","marker":{"colorbar":{"outlinewidth":0,"ticks":""}}}],"scatterpolar":[{"type":"scatterpolar","marker":{"colorbar":{"outlinewidth":0,"ticks":""}}}],"histogram":[{"marker":{"pattern":{"fillmode":"overlay","size":10,"solidity":0.2}},"type":"histogram"}],"scattergl":[{"type":"scattergl","marker":{"colorbar":{"outlinewidth":0,"ticks":""}}}],"scatter3d":[{"type":"scatter3d","line":{"colorbar":{"outlinewidth":0,"ticks":""}},"marker":{"colorbar":{"outlinewidth":0,"ticks":""}}}],"scattermapbox":[{"type":"scattermapbox","marker":{"colorbar":{"outlinewidth":0,"ticks":""}}}],"scatterternary":[{"type":"scatterternary","marker":{"colorbar":{"outlinewidth":0,"ticks":""}}}],"scattercarpet":[{"type":"scattercarpet","marker":{"colorbar":{"outlinewidth":0,"ticks":""}}}],"carpet":[{"aaxis":{"endlinecolor":"#2a3f5f","gridcolor":"white","linecolor":"white","minorgridcolor":"white","startlinecolor":"#2a3f5f"},"baxis":{"endlinecolor":"#2a3f5f","gridcolor":"white","linecolor":"white","minorgridcolor":"white","startlinecolor":"#2a3f5f"},"type":"carpet"}],"table":[{"cells":{"fill":{"color":"#EBF0F8"},"line":{"color":"white"}},"header":{"fill":{"color":"#C8D4E3"},"line":{"color":"white"}},"type":"table"}],"barpolar":[{"marker":{"line":{"color":"#E5ECF6","width":0.5},"pattern":{"fillmode":"overlay","size":10,"solidity":0.2}},"type":"barpolar"}],"pie":[{"automargin":true,"type":"pie"}]},"layout":{"autotypenumbers":"strict","colorway":["#636efa","#EF553B","#00cc96","#ab63fa","#FFA15A","#19d3f3","#FF6692","#B6E880","#FF97FF","#FECB52"],"font":{"color":"#2a3f5f"},"hovermode":"closest","hoverlabel":{"align":"left"},"paper_bgcolor":"white","plot_bgcolor":"#E5ECF6","polar":{"bgcolor":"#E5ECF6","angularaxis":{"gridcolor":"white","linecolor":"white","ticks":""},"radialaxis":{"gridcolor":"white","linecolor":"white","ticks":""}},"ternary":{"bgcolor":"#E5ECF6","aaxis":{"gridcolor":"white","linecolor":"white","ticks":""},"baxis":{"gridcolor":"white","linecolor":"white","ticks":""},"caxis":{"gridcolor":"white","linecolor":"white","ticks":""}},"coloraxis":{"colorbar":{"outlinewidth":0,"ticks":""}},"colorscale":{"sequential":[[0.0,"#0d0887"],[0.1111111111111111,"#46039f"],[0.2222222222222222,"#7201a8"],[0.3333333333333333,"#9c179e"],[0.4444444444444444,"#bd3786"],[0.5555555555555556,"#d8576b"],[0.6666666666666666,"#ed7953"],[0.7777777777777778,"#fb9f3a"],[0.8888888888888888,"#fdca26"],[1.0,"#f0f921"]],"sequentialminus":[[0.0,"#0d0887"],[0.1111111111111111,"#46039f"],[0.2222222222222222,"#7201a8"],[0.3333333333333333,"#9c179e"],[0.4444444444444444,"#bd3786"],[0.5555555555555556,"#d8576b"],[0.6666666666666666,"#ed7953"],[0.7777777777777778,"#fb9f3a"],[0.8888888888888888,"#fdca26"],[1.0,"#f0f921"]],"diverging":[[0,"#8e0152"],[0.1,"#c51b7d"],[0.2,"#de77ae"],[0.3,"#f1b6da"],[0.4,"#fde0ef"],[0.5,"#f7f7f7"],[0.6,"#e6f5d0"],[0.7,"#b8e186"],[0.8,"#7fbc41"],[0.9,"#4d9221"],[1,"#276419"]]},"xaxis":{"gridcolor":"white","linecolor":"white","ticks":"","title":{"standoff":15},"zerolinecolor":"white","automargin":true,"zerolinewidth":2},"yaxis":{"gridcolor":"white","linecolor":"white","ticks":"","title":{"standoff":15},"zerolinecolor":"white","automargin":true,"zerolinewidth":2},"scene":{"xaxis":{"backgroundcolor":"#E5ECF6","gridcolor":"white","linecolor":"white","showbackground":true,"ticks":"","zerolinecolor":"white","gridwidth":2},"yaxis":{"backgroundcolor":"#E5ECF6","gridcolor":"white","linecolor":"white","showbackground":true,"ticks":"","zerolinecolor":"white","gridwidth":2},"zaxis":{"backgroundcolor":"#E5ECF6","gridcolor":"white","linecolor":"white","showbackground":true,"ticks":"","zerolinecolor":"white","gridwidth":2}},"shapedefaults":{"line":{"color":"#2a3f5f"}},"annotationdefaults":{"arrowcolor":"#2a3f5f","arrowhead":0,"arrowwidth":1},"geo":{"bgcolor":"white","landcolor":"#E5ECF6","subunitcolor":"white","showland":true,"showlakes":true,"lakecolor":"white"},"title":{"x":0.05},"mapbox":{"style":"light"}}},"xaxis":{"anchor":"y","domain":[0.0,1.0],"title":{"text":"GDP per capita"}},"yaxis":{"anchor":"x","domain":[0.0,1.0],"title":{"text":"Consumer Expenditure (as % of GDP)"}},"legend":{"title":{"text":"Income Level"},"tracegroupgap":0},"title":{"text":"Consumer Expenditure (as % of GDP) vs GDP per capita (2018)"}},                        {"responsive": true}                    ).then(function(){

var gd = document.getElementById('5cc5557e-2f6e-4ae3-872c-fb9189f73d51');
var x = new MutationObserver(function (mutations, observer) {{
        var display = window.getComputedStyle(gd).display;
        if (!display || display === 'none') {{
            console.log([gd, 'removed!']);
            Plotly.purge(gd);
            observer.disconnect();
        }}
}});

// Listen for the removal of the full notebook cells
var notebookContainer = gd.closest('#notebook-container');
if (notebookContainer) {{
    x.observe(notebookContainer, {childList: true});
}}

// Listen for the clearing of the current output cell
var outputEl = gd.closest('.output');
if (outputEl) {{
    x.observe(outputEl, {childList: true});
}}

                        })                };                            </script>        </div>
</body>
</html>



<html>
<head><meta charset="utf-8" /></head>
<body>
    <div>            <script src="https://cdnjs.cloudflare.com/ajax/libs/mathjax/2.7.5/MathJax.js?config=TeX-AMS-MML_SVG"></script><script type="text/javascript">if (window.MathJax && window.MathJax.Hub && window.MathJax.Hub.Config) {window.MathJax.Hub.Config({SVG: {font: "STIX-Web"}});}</script>                <script type="text/javascript">window.PlotlyConfig = {MathJaxConfig: 'local'};</script>
        <script charset="utf-8" src="https://cdn.plot.ly/plotly-2.24.1.min.js"></script>                <div id="beea1908-a2f7-428b-8051-f84a53080da8" class="plotly-graph-div" style="height:525px; width:100%;"></div>            <script type="text/javascript">                                    window.PLOTLYENV=window.PLOTLYENV || {};                                    if (document.getElementById("beea1908-a2f7-428b-8051-f84a53080da8")) {                    Plotly.newPlot(                        "beea1908-a2f7-428b-8051-f84a53080da8",                        [{"customdata":[["Afghanistan"],["Benin"],["Burkina Faso"],["Burundi"],["Central African Republic"],["Chad"],["Ethiopia"],["Guinea"],["Guinea-Bissau"],["Haiti"],["Liberia"],["Madagascar"],["Malawi"],["Mali"],["Mozambique"],["Nepal"],["Niger"],["Rwanda"],["Sierra Leone"],["Syrian Arab Republic"],["Tajikistan"],["Togo"],["Uganda"]],"hovertemplate":"Income Level=Low income\u003cbr\u003eGDP per capita=%{x}\u003cbr\u003eGovernment Expenditure (as % of GDP)=%{y}\u003cbr\u003eCountry Name=%{customdata[0]}\u003cextra\u003e\u003c\u002fextra\u003e","legendgroup":"Low income","marker":{"color":"#636efa","symbol":"circle"},"mode":"markers","name":"Low income","orientation":"v","showlegend":true,"x":[null,1.3045363065075943,0.9423917056106909,0.2997825084701306,0.416426157737857,0.7634076046419629,0.8424703094577008,1.1541776261411962,0.9539180675900872,1.6420406955759412,null,0.6187352659533052,null,1.1801675454169258,null,1.034949667840119,0.6888681585022614,0.9335541169168238,0.6955406414196662,1.472296369124743,0.9669804348483436,0.9618428718740492,0.8312195928096361],"xaxis":"x","y":[null,9.47059133643367,15.765641880031886,20.767143582128167,7.148304570657866,3.4780647398027367,9.630294200036897,13.415629573543317,10.861209732162331,7.651806821954367,null,11.7788527089972,null,13.913129947454411,null,8.678890841472326,13.317871645242413,12.77614970616935,8.598023773744949,13.765795953312496,10.472260382820114,11.800578075702918,8.081604329627506],"yaxis":"y","type":"scatter"},{"customdata":[["Albania"],["Algeria"],["Argentina"],["Armenia"],["Azerbaijan"],["Belarus"],["Bosnia and Herzegovina"],["Botswana"],["Brazil"],["Bulgaria"],["China"],["Colombia"],["Costa Rica"],["Cuba"],["Dominica"],["Dominican Republic"],["Ecuador"],["Equatorial Guinea"],["Gabon"],["Georgia"],["Guatemala"],["Iraq"],["Jamaica"],["Jordan"],["Kazakhstan"],["Lebanon"],["Libya"],["Malaysia"],["Mauritius"],["Mexico"],["Montenegro"],["Namibia"],["Paraguay"],["Peru"],["Romania"],["Russian Federation"],["Serbia"],["South Africa"],["Sri Lanka"],["Thailand"],["Turkmenistan"]],"hovertemplate":"Income Level=Upper middle income\u003cbr\u003eGDP per capita=%{x}\u003cbr\u003eGovernment Expenditure (as % of GDP)=%{y}\u003cbr\u003eCountry Name=%{customdata[0]}\u003cextra\u003e\u003c\u002fextra\u003e","legendgroup":"Upper middle income","marker":{"color":"#EF553B","symbol":"circle"},"mode":"markers","name":"Upper middle income","orientation":"v","showlegend":true,"x":[5.5365187015336,4.656358067756523,13.43816667529076,4.53545424780213,5.482806843127045,7.105367136361758,6.2605263652189125,9.71505031393233,10.876767251472902,10.55388901479824,11.543151777277965,8.017000102028279,14.503687986721852,11.65152806719012,null,9.131555105147369,7.4030035575351025,20.316898888639383,8.952159065170372,3.941293671607263,4.724665386900773,5.9819376990495545,6.677127903147384,5.365306694425017,9.947973864860291,8.165175918858733,15.624896937081882,12.934681764340768,12.284721444129024,11.4446752397259,10.385329667663044,6.82081880482101,6.158991030732602,7.993207106169597,14.542213099406409,13.175549950866124,8.1508594160437,8.721878107745141,4.404444202132617,8.470822302692627,null],"xaxis":"x","y":[10.088174455698391,15.624930632322451,13.81054247645383,10.85412680500621,9.321783224170716,13.956809499300457,16.295859102220213,22.546700792037548,16.59348835359565,14.409653145469182,14.36710138437522,13.35726555382426,13.95838124312441,23.20823328675216,null,9.797323245164687,12.960052741450362,19.01908178692875,9.556122557006931,11.981620249456908,10.01592921458297,15.08438245012671,11.84928042048654,14.847237020186023,8.18695352725627,13.379280062183662,25.930682519208126,10.661067725156949,12.803678338769377,10.156703920707194,15.97431260732701,19.92429492381623,10.599461972837444,11.604843630029729,14.525831485234834,15.20898997549271,14.517923541300403,16.248200586369403,8.499148575094335,14.331380573623436,null],"yaxis":"y","type":"scatter"},{"customdata":[["Angola"],["Bangladesh"],["Cabo Verde"],["Cambodia"],["Cameroon"],["Comoros"],["Djibouti"],["El Salvador"],["Ghana"],["Honduras"],["India"],["Indonesia"],["Kenya"],["Lesotho"],["Mauritania"],["Mongolia"],["Morocco"],["Myanmar"],["Nicaragua"],["Nigeria"],["Pakistan"],["Philippines"],["Senegal"],["Tunisia"],["Ukraine"],["Uzbekistan"],["Zambia"],["Zimbabwe"]],"hovertemplate":"Income Level=Lower middle income\u003cbr\u003eGDP per capita=%{x}\u003cbr\u003eGovernment Expenditure (as % of GDP)=%{y}\u003cbr\u003eCountry Name=%{customdata[0]}\u003cextra\u003e\u003c\u002fextra\u003e","legendgroup":"Lower middle income","marker":{"color":"#00cc96","symbol":"circle"},"mode":"markers","name":"Lower middle income","orientation":"v","showlegend":true,"x":[3.8535590703151663,1.9989045745475744,null,1.518061006773532,1.6965255969857094,1.5942202502252845,4.846573798428586,4.695081976480254,2.575051818847171,2.9848769472429204,2.2203459660510787,4.267266456476381,2.0024417354026625,1.8573921671666676,1.935872794284197,4.253117361651591,4.079512244786143,null,2.4211697513353463,null,1.769331600016486,3.470580341600621,1.5473027586138857,4.277700999187144,3.568588701314224,1.807796971100641,1.624343950010044,2.5992548853101973],"xaxis":"x","y":[9.539672998684328,5.720864076826229,null,4.859342622303737,10.649336728331887,9.289494240480565,14.518274791271788,14.01966492898144,6.665238629623604,12.05889318517755,10.149636301817033,8.491207221474841,11.068359209745951,26.69323381371817,13.052460854455449,12.672647191880271,15.825351080556317,null,13.086705500727062,null,10.059719046246448,10.735662944162463,12.591283841318992,15.986069763523004,17.334249967302135,13.086521103299935,11.93055571191858,9.670821183274892],"yaxis":"y","type":"scatter"},{"customdata":[["Australia"],["Austria"],["Bahrain"],["Barbados"],["Belgium"],["Canada"],["Chile"],["Croatia"],["Cyprus"],["Denmark"],["Estonia"],["Finland"],["France"],["Germany"],["Greece"],["Hungary"],["Iceland"],["Ireland"],["Israel"],["Italy"],["Japan"],["Kuwait"],["Latvia"],["Lithuania"],["Luxembourg"],["Malta"],["Netherlands"],["New Zealand"],["Norway"],["Oman"],["Panama"],["Poland"],["Portugal"],["Puerto Rico"],["Qatar"],["Saudi Arabia"],["Seychelles"],["Singapore"],["Slovenia"],["Spain"],["Sweden"],["Switzerland"],["Trinidad and Tobago"],["United Arab Emirates"],["United Kingdom"],["United States"],["Uruguay"]],"hovertemplate":"Income Level=High income\u003cbr\u003eGDP per capita=%{x}\u003cbr\u003eGovernment Expenditure (as % of GDP)=%{y}\u003cbr\u003eCountry Name=%{customdata[0]}\u003cextra\u003e\u003c\u002fextra\u003e","legendgroup":"High income","marker":{"color":"#ab63fa","symbol":"circle"},"mode":"markers","name":"High income","orientation":"v","showlegend":true,"x":[68.92380225582335,60.22665665211098,26.36956722236935,19.824924692373035,57.68378367988274,55.63555110471394,18.01217512805355,19.065584831786992,28.55178058696604,76.00629771784118,28.01822462101277,60.83959658667786,50.926428954480215,56.2160279207692,23.42278611341433,19.322318189192536,92.26640606413878,88.76210929938102,53.980370920364,40.90619262622918,47.74192480394642,null,20.86504572808823,22.45774398827238,135.03389024507197,36.30902284819293,65.68873805572721,51.55460942711251,98.64377489854924,23.312104382606304,null,17.636314749583878,27.548883136669264,33.667706137206466,null,30.01028424970493,20.49769509749656,66.8551394051294,30.48046667854283,35.31277554830795,68.3609054340486,93.86419816759827,null,46.363776580562345,50.915604206352434,71.19717335877542,null],"xaxis":"x","y":[16.6831136406723,16.429910285320446,14.7407600804911,10.342780444995096,19.07030590588812,17.2378581270915,13.066013381778404,18.24498588280185,12.745796177313116,19.67154734987285,16.184405238129248,18.81644934804413,19.027202327081103,16.70427423141646,16.791205863520563,16.74334468218131,19.49319167816061,10.77625831946969,18.4335429366686,15.973721739041558,16.413892979065814,null,15.323279447185534,13.998320163859072,14.490617687364509,13.40004810740269,19.67809515462993,15.480076206534129,19.39651743850049,17.909517412030816,null,15.35698548229444,14.609110331893236,7.25966327841511,null,19.96689106552693,18.131540123445227,9.381236122171863,15.69337598191022,15.90227471806893,20.80911691654602,10.046020824562063,null,11.18903706003962,15.665746633885185,12.282867743623092,null],"yaxis":"y","type":"scatter"}],                        {"template":{"data":{"histogram2dcontour":[{"type":"histogram2dcontour","colorbar":{"outlinewidth":0,"ticks":""},"colorscale":[[0.0,"#0d0887"],[0.1111111111111111,"#46039f"],[0.2222222222222222,"#7201a8"],[0.3333333333333333,"#9c179e"],[0.4444444444444444,"#bd3786"],[0.5555555555555556,"#d8576b"],[0.6666666666666666,"#ed7953"],[0.7777777777777778,"#fb9f3a"],[0.8888888888888888,"#fdca26"],[1.0,"#f0f921"]]}],"choropleth":[{"type":"choropleth","colorbar":{"outlinewidth":0,"ticks":""}}],"histogram2d":[{"type":"histogram2d","colorbar":{"outlinewidth":0,"ticks":""},"colorscale":[[0.0,"#0d0887"],[0.1111111111111111,"#46039f"],[0.2222222222222222,"#7201a8"],[0.3333333333333333,"#9c179e"],[0.4444444444444444,"#bd3786"],[0.5555555555555556,"#d8576b"],[0.6666666666666666,"#ed7953"],[0.7777777777777778,"#fb9f3a"],[0.8888888888888888,"#fdca26"],[1.0,"#f0f921"]]}],"heatmap":[{"type":"heatmap","colorbar":{"outlinewidth":0,"ticks":""},"colorscale":[[0.0,"#0d0887"],[0.1111111111111111,"#46039f"],[0.2222222222222222,"#7201a8"],[0.3333333333333333,"#9c179e"],[0.4444444444444444,"#bd3786"],[0.5555555555555556,"#d8576b"],[0.6666666666666666,"#ed7953"],[0.7777777777777778,"#fb9f3a"],[0.8888888888888888,"#fdca26"],[1.0,"#f0f921"]]}],"heatmapgl":[{"type":"heatmapgl","colorbar":{"outlinewidth":0,"ticks":""},"colorscale":[[0.0,"#0d0887"],[0.1111111111111111,"#46039f"],[0.2222222222222222,"#7201a8"],[0.3333333333333333,"#9c179e"],[0.4444444444444444,"#bd3786"],[0.5555555555555556,"#d8576b"],[0.6666666666666666,"#ed7953"],[0.7777777777777778,"#fb9f3a"],[0.8888888888888888,"#fdca26"],[1.0,"#f0f921"]]}],"contourcarpet":[{"type":"contourcarpet","colorbar":{"outlinewidth":0,"ticks":""}}],"contour":[{"type":"contour","colorbar":{"outlinewidth":0,"ticks":""},"colorscale":[[0.0,"#0d0887"],[0.1111111111111111,"#46039f"],[0.2222222222222222,"#7201a8"],[0.3333333333333333,"#9c179e"],[0.4444444444444444,"#bd3786"],[0.5555555555555556,"#d8576b"],[0.6666666666666666,"#ed7953"],[0.7777777777777778,"#fb9f3a"],[0.8888888888888888,"#fdca26"],[1.0,"#f0f921"]]}],"surface":[{"type":"surface","colorbar":{"outlinewidth":0,"ticks":""},"colorscale":[[0.0,"#0d0887"],[0.1111111111111111,"#46039f"],[0.2222222222222222,"#7201a8"],[0.3333333333333333,"#9c179e"],[0.4444444444444444,"#bd3786"],[0.5555555555555556,"#d8576b"],[0.6666666666666666,"#ed7953"],[0.7777777777777778,"#fb9f3a"],[0.8888888888888888,"#fdca26"],[1.0,"#f0f921"]]}],"mesh3d":[{"type":"mesh3d","colorbar":{"outlinewidth":0,"ticks":""}}],"scatter":[{"fillpattern":{"fillmode":"overlay","size":10,"solidity":0.2},"type":"scatter"}],"parcoords":[{"type":"parcoords","line":{"colorbar":{"outlinewidth":0,"ticks":""}}}],"scatterpolargl":[{"type":"scatterpolargl","marker":{"colorbar":{"outlinewidth":0,"ticks":""}}}],"bar":[{"error_x":{"color":"#2a3f5f"},"error_y":{"color":"#2a3f5f"},"marker":{"line":{"color":"#E5ECF6","width":0.5},"pattern":{"fillmode":"overlay","size":10,"solidity":0.2}},"type":"bar"}],"scattergeo":[{"type":"scattergeo","marker":{"colorbar":{"outlinewidth":0,"ticks":""}}}],"scatterpolar":[{"type":"scatterpolar","marker":{"colorbar":{"outlinewidth":0,"ticks":""}}}],"histogram":[{"marker":{"pattern":{"fillmode":"overlay","size":10,"solidity":0.2}},"type":"histogram"}],"scattergl":[{"type":"scattergl","marker":{"colorbar":{"outlinewidth":0,"ticks":""}}}],"scatter3d":[{"type":"scatter3d","line":{"colorbar":{"outlinewidth":0,"ticks":""}},"marker":{"colorbar":{"outlinewidth":0,"ticks":""}}}],"scattermapbox":[{"type":"scattermapbox","marker":{"colorbar":{"outlinewidth":0,"ticks":""}}}],"scatterternary":[{"type":"scatterternary","marker":{"colorbar":{"outlinewidth":0,"ticks":""}}}],"scattercarpet":[{"type":"scattercarpet","marker":{"colorbar":{"outlinewidth":0,"ticks":""}}}],"carpet":[{"aaxis":{"endlinecolor":"#2a3f5f","gridcolor":"white","linecolor":"white","minorgridcolor":"white","startlinecolor":"#2a3f5f"},"baxis":{"endlinecolor":"#2a3f5f","gridcolor":"white","linecolor":"white","minorgridcolor":"white","startlinecolor":"#2a3f5f"},"type":"carpet"}],"table":[{"cells":{"fill":{"color":"#EBF0F8"},"line":{"color":"white"}},"header":{"fill":{"color":"#C8D4E3"},"line":{"color":"white"}},"type":"table"}],"barpolar":[{"marker":{"line":{"color":"#E5ECF6","width":0.5},"pattern":{"fillmode":"overlay","size":10,"solidity":0.2}},"type":"barpolar"}],"pie":[{"automargin":true,"type":"pie"}]},"layout":{"autotypenumbers":"strict","colorway":["#636efa","#EF553B","#00cc96","#ab63fa","#FFA15A","#19d3f3","#FF6692","#B6E880","#FF97FF","#FECB52"],"font":{"color":"#2a3f5f"},"hovermode":"closest","hoverlabel":{"align":"left"},"paper_bgcolor":"white","plot_bgcolor":"#E5ECF6","polar":{"bgcolor":"#E5ECF6","angularaxis":{"gridcolor":"white","linecolor":"white","ticks":""},"radialaxis":{"gridcolor":"white","linecolor":"white","ticks":""}},"ternary":{"bgcolor":"#E5ECF6","aaxis":{"gridcolor":"white","linecolor":"white","ticks":""},"baxis":{"gridcolor":"white","linecolor":"white","ticks":""},"caxis":{"gridcolor":"white","linecolor":"white","ticks":""}},"coloraxis":{"colorbar":{"outlinewidth":0,"ticks":""}},"colorscale":{"sequential":[[0.0,"#0d0887"],[0.1111111111111111,"#46039f"],[0.2222222222222222,"#7201a8"],[0.3333333333333333,"#9c179e"],[0.4444444444444444,"#bd3786"],[0.5555555555555556,"#d8576b"],[0.6666666666666666,"#ed7953"],[0.7777777777777778,"#fb9f3a"],[0.8888888888888888,"#fdca26"],[1.0,"#f0f921"]],"sequentialminus":[[0.0,"#0d0887"],[0.1111111111111111,"#46039f"],[0.2222222222222222,"#7201a8"],[0.3333333333333333,"#9c179e"],[0.4444444444444444,"#bd3786"],[0.5555555555555556,"#d8576b"],[0.6666666666666666,"#ed7953"],[0.7777777777777778,"#fb9f3a"],[0.8888888888888888,"#fdca26"],[1.0,"#f0f921"]],"diverging":[[0,"#8e0152"],[0.1,"#c51b7d"],[0.2,"#de77ae"],[0.3,"#f1b6da"],[0.4,"#fde0ef"],[0.5,"#f7f7f7"],[0.6,"#e6f5d0"],[0.7,"#b8e186"],[0.8,"#7fbc41"],[0.9,"#4d9221"],[1,"#276419"]]},"xaxis":{"gridcolor":"white","linecolor":"white","ticks":"","title":{"standoff":15},"zerolinecolor":"white","automargin":true,"zerolinewidth":2},"yaxis":{"gridcolor":"white","linecolor":"white","ticks":"","title":{"standoff":15},"zerolinecolor":"white","automargin":true,"zerolinewidth":2},"scene":{"xaxis":{"backgroundcolor":"#E5ECF6","gridcolor":"white","linecolor":"white","showbackground":true,"ticks":"","zerolinecolor":"white","gridwidth":2},"yaxis":{"backgroundcolor":"#E5ECF6","gridcolor":"white","linecolor":"white","showbackground":true,"ticks":"","zerolinecolor":"white","gridwidth":2},"zaxis":{"backgroundcolor":"#E5ECF6","gridcolor":"white","linecolor":"white","showbackground":true,"ticks":"","zerolinecolor":"white","gridwidth":2}},"shapedefaults":{"line":{"color":"#2a3f5f"}},"annotationdefaults":{"arrowcolor":"#2a3f5f","arrowhead":0,"arrowwidth":1},"geo":{"bgcolor":"white","landcolor":"#E5ECF6","subunitcolor":"white","showland":true,"showlakes":true,"lakecolor":"white"},"title":{"x":0.05},"mapbox":{"style":"light"}}},"xaxis":{"anchor":"y","domain":[0.0,1.0],"title":{"text":"GDP per capita"}},"yaxis":{"anchor":"x","domain":[0.0,1.0],"title":{"text":"Government Expenditure (as % of GDP)"}},"legend":{"title":{"text":"Income Level"},"tracegroupgap":0},"title":{"text":"Government Expenditure (as % of GDP) vs GDP per capita (2018)"}},                        {"responsive": true}                    ).then(function(){

var gd = document.getElementById('beea1908-a2f7-428b-8051-f84a53080da8');
var x = new MutationObserver(function (mutations, observer) {{
        var display = window.getComputedStyle(gd).display;
        if (!display || display === 'none') {{
            console.log([gd, 'removed!']);
            Plotly.purge(gd);
            observer.disconnect();
        }}
}});

// Listen for the removal of the full notebook cells
var notebookContainer = gd.closest('#notebook-container');
if (notebookContainer) {{
    x.observe(notebookContainer, {childList: true});
}}

// Listen for the clearing of the current output cell
var outputEl = gd.closest('.output');
if (outputEl) {{
    x.observe(outputEl, {childList: true});
}}

                        })                };                            </script>        </div>
</body>
</html>



<html>
<head><meta charset="utf-8" /></head>
<body>
    <div>            <script src="https://cdnjs.cloudflare.com/ajax/libs/mathjax/2.7.5/MathJax.js?config=TeX-AMS-MML_SVG"></script><script type="text/javascript">if (window.MathJax && window.MathJax.Hub && window.MathJax.Hub.Config) {window.MathJax.Hub.Config({SVG: {font: "STIX-Web"}});}</script>                <script type="text/javascript">window.PlotlyConfig = {MathJaxConfig: 'local'};</script>
        <script charset="utf-8" src="https://cdn.plot.ly/plotly-2.24.1.min.js"></script>                <div id="eae1aeb7-65be-44fc-845e-359dcdfcdacd" class="plotly-graph-div" style="height:525px; width:100%;"></div>            <script type="text/javascript">                                    window.PLOTLYENV=window.PLOTLYENV || {};                                    if (document.getElementById("eae1aeb7-65be-44fc-845e-359dcdfcdacd")) {                    Plotly.newPlot(                        "eae1aeb7-65be-44fc-845e-359dcdfcdacd",                        [{"customdata":[["Afghanistan"],["Benin"],["Burkina Faso"],["Burundi"],["Central African Republic"],["Chad"],["Ethiopia"],["Guinea"],["Guinea-Bissau"],["Haiti"],["Liberia"],["Madagascar"],["Malawi"],["Mali"],["Mozambique"],["Nepal"],["Niger"],["Rwanda"],["Sierra Leone"],["Syrian Arab Republic"],["Tajikistan"],["Togo"],["Uganda"]],"hovertemplate":"Income Level=Low income\u003cbr\u003eGDP per capita=%{x}\u003cbr\u003eInvestment Expenditure (as % of GDP)=%{y}\u003cbr\u003eCountry Name=%{customdata[0]}\u003cextra\u003e\u003c\u002fextra\u003e","legendgroup":"Low income","marker":{"color":"#636efa","symbol":"circle"},"mode":"markers","name":"Low income","orientation":"v","showlegend":true,"x":[null,1.3045363065075943,0.9423917056106909,0.2997825084701306,0.416426157737857,0.7634076046419629,0.8424703094577008,1.1541776261411962,0.9539180675900872,1.6420406955759412,null,0.6187352659533052,null,1.1801675454169258,null,1.034949667840119,0.6888681585022614,0.9335541169168238,0.6955406414196662,1.472296369124743,0.9669804348483436,0.9618428718740492,0.8312195928096361],"xaxis":"x","y":[null,23.562126520884902,17.248863916274072,8.797572770923122,15.223065340715197,20.14172754943328,32.62761080327679,16.869213386299396,17.94792636068134,14.86305863814114,null,18.21124267284795,null,16.384870361112764,null,34.91659849938601,24.948190074860506,19.89222677497649,12.152739578687523,7.787212815986573,33.026968670951746,15.923568191276855,22.22557695493796],"yaxis":"y","type":"scatter"},{"customdata":[["Albania"],["Algeria"],["Argentina"],["Armenia"],["Azerbaijan"],["Belarus"],["Bosnia and Herzegovina"],["Botswana"],["Brazil"],["Bulgaria"],["China"],["Colombia"],["Costa Rica"],["Cuba"],["Dominica"],["Dominican Republic"],["Ecuador"],["Equatorial Guinea"],["Gabon"],["Georgia"],["Guatemala"],["Iraq"],["Jamaica"],["Jordan"],["Kazakhstan"],["Lebanon"],["Libya"],["Malaysia"],["Mauritius"],["Mexico"],["Montenegro"],["Namibia"],["Paraguay"],["Peru"],["Romania"],["Russian Federation"],["Serbia"],["South Africa"],["Sri Lanka"],["Thailand"],["Turkmenistan"]],"hovertemplate":"Income Level=Upper middle income\u003cbr\u003eGDP per capita=%{x}\u003cbr\u003eInvestment Expenditure (as % of GDP)=%{y}\u003cbr\u003eCountry Name=%{customdata[0]}\u003cextra\u003e\u003c\u002fextra\u003e","legendgroup":"Upper middle income","marker":{"color":"#EF553B","symbol":"circle"},"mode":"markers","name":"Upper middle income","orientation":"v","showlegend":true,"x":[5.5365187015336,4.656358067756523,13.43816667529076,4.53545424780213,5.482806843127045,7.105367136361758,6.2605263652189125,9.71505031393233,10.876767251472902,10.55388901479824,11.543151777277965,8.017000102028279,14.503687986721852,11.65152806719012,null,9.131555105147369,7.4030035575351025,20.316898888639383,8.952159065170372,3.941293671607263,4.724665386900773,5.9819376990495545,6.677127903147384,5.365306694425017,9.947973864860291,8.165175918858733,15.624896937081882,12.934681764340768,12.284721444129024,11.4446752397259,10.385329667663044,6.82081880482101,6.158991030732602,7.993207106169597,14.542213099406409,13.175549950866124,8.1508594160437,8.721878107745141,4.404444202132617,8.470822302692627,null],"xaxis":"x","y":[21.32892106871345,36.45432388157106,13.326413931844376,15.819001326334533,18.430838346658955,23.256033114167035,18.58638319615148,20.45072273974605,12.591572128015438,16.464571796147595,37.224075120515614,18.38645158065769,15.688239608716083,8.842444971163422,null,23.258535666015455,22.52990742826488,10.250184959611133,17.417892135239143,22.81338735792103,12.335784890261602,13.460977428329674,20.52855721773897,18.08103204998992,20.835177633319475,19.00145332908728,11.795188155459591,21.55511506035761,15.867143748846123,20.79603638952301,25.24993909342884,13.249084672681551,18.35438264984149,18.56716758266084,18.645441905010387,17.73727588727308,17.59126797330885,13.368310659952396,30.349140435117068,20.190352401584896,null],"yaxis":"y","type":"scatter"},{"customdata":[["Angola"],["Bangladesh"],["Cabo Verde"],["Cambodia"],["Cameroon"],["Comoros"],["Djibouti"],["El Salvador"],["Ghana"],["Honduras"],["India"],["Indonesia"],["Kenya"],["Lesotho"],["Mauritania"],["Mongolia"],["Morocco"],["Myanmar"],["Nicaragua"],["Nigeria"],["Pakistan"],["Philippines"],["Senegal"],["Tunisia"],["Ukraine"],["Uzbekistan"],["Zambia"],["Zimbabwe"]],"hovertemplate":"Income Level=Lower middle income\u003cbr\u003eGDP per capita=%{x}\u003cbr\u003eInvestment Expenditure (as % of GDP)=%{y}\u003cbr\u003eCountry Name=%{customdata[0]}\u003cextra\u003e\u003c\u002fextra\u003e","legendgroup":"Lower middle income","marker":{"color":"#00cc96","symbol":"circle"},"mode":"markers","name":"Lower middle income","orientation":"v","showlegend":true,"x":[3.8535590703151663,1.9989045745475744,null,1.518061006773532,1.6965255969857094,1.5942202502252845,4.846573798428586,4.695081976480254,2.575051818847171,2.9848769472429204,2.2203459660510787,4.267266456476381,2.0024417354026625,1.8573921671666676,1.935872794284197,4.253117361651591,4.079512244786143,null,2.4211697513353463,null,1.769331600016486,3.470580341600621,1.5473027586138857,4.277700999187144,3.568588701314224,1.807796971100641,1.624343950010044,2.5992548853101973],"xaxis":"x","y":[15.66004295642373,30.55001260191153,null,22.24464116301019,17.465993648883217,13.402938986867344,19.375996581864698,14.941941335648613,19.887598297217437,22.16759345777293,27.62943622181659,30.39145048180315,17.117887280440243,18.218455948653176,33.11656706778919,26.80241341035783,24.498642912796942,null,19.78988306760396,null,14.05360669626643,24.32197659241004,25.887380866068945,17.04045570278674,14.726835732973552,30.57290425002418,32.96045016175896,10.299117024643833],"yaxis":"y","type":"scatter"},{"customdata":[["Australia"],["Austria"],["Bahrain"],["Barbados"],["Belgium"],["Canada"],["Chile"],["Croatia"],["Cyprus"],["Denmark"],["Estonia"],["Finland"],["France"],["Germany"],["Greece"],["Hungary"],["Iceland"],["Ireland"],["Israel"],["Italy"],["Japan"],["Kuwait"],["Latvia"],["Lithuania"],["Luxembourg"],["Malta"],["Netherlands"],["New Zealand"],["Norway"],["Oman"],["Panama"],["Poland"],["Portugal"],["Puerto Rico"],["Qatar"],["Saudi Arabia"],["Seychelles"],["Singapore"],["Slovenia"],["Spain"],["Sweden"],["Switzerland"],["Trinidad and Tobago"],["United Arab Emirates"],["United Kingdom"],["United States"],["Uruguay"]],"hovertemplate":"Income Level=High income\u003cbr\u003eGDP per capita=%{x}\u003cbr\u003eInvestment Expenditure (as % of GDP)=%{y}\u003cbr\u003eCountry Name=%{customdata[0]}\u003cextra\u003e\u003c\u002fextra\u003e","legendgroup":"High income","marker":{"color":"#ab63fa","symbol":"circle"},"mode":"markers","name":"High income","orientation":"v","showlegend":true,"x":[68.92380225582335,60.22665665211098,26.36956722236935,19.824924692373035,57.68378367988274,55.63555110471394,18.01217512805355,19.065584831786992,28.55178058696604,76.00629771784118,28.01822462101277,60.83959658667786,50.926428954480215,56.2160279207692,23.42278611341433,19.322318189192536,92.26640606413878,88.76210929938102,53.980370920364,40.90619262622918,47.74192480394642,null,20.86504572808823,22.45774398827238,135.03389024507197,36.30902284819293,65.68873805572721,51.55460942711251,98.64377489854924,23.312104382606304,null,17.636314749583878,27.548883136669264,33.667706137206466,null,30.01028424970493,20.49769509749656,66.8551394051294,30.48046667854283,35.31277554830795,68.3609054340486,93.86419816759827,null,46.363776580562345,50.915604206352434,71.19717335877542,null],"xaxis":"x","y":[20.334703839090224,20.470188837078517,26.666178455895466,12.346635004215925,19.46685721000417,18.900393991994893,20.27189655488476,16.718421265690758,16.470848371069284,17.606733414942504,22.92389362791761,19.780745746009963,18.71735845296711,17.697623196915107,9.465433554559196,21.027135018681943,17.628477034716937,25.4569095253791,19.085694436128893,15.098313033727626,21.19961853709549,null,18.9349203820604,17.90429893366229,13.972989075308146,16.815735550003204,16.49410213233008,19.947642672331312,19.95146254114691,25.33026073775349,null,16.300638389538317,15.078435899059144,14.08217449119881,null,17.53066425858153,45.3629345921746,21.07589671622336,16.627517645742763,16.51642812725208,20.10661342610739,23.724198618619862,null,16.400708010165825,15.204840437580206,18.40174892991492,null],"yaxis":"y","type":"scatter"}],                        {"template":{"data":{"histogram2dcontour":[{"type":"histogram2dcontour","colorbar":{"outlinewidth":0,"ticks":""},"colorscale":[[0.0,"#0d0887"],[0.1111111111111111,"#46039f"],[0.2222222222222222,"#7201a8"],[0.3333333333333333,"#9c179e"],[0.4444444444444444,"#bd3786"],[0.5555555555555556,"#d8576b"],[0.6666666666666666,"#ed7953"],[0.7777777777777778,"#fb9f3a"],[0.8888888888888888,"#fdca26"],[1.0,"#f0f921"]]}],"choropleth":[{"type":"choropleth","colorbar":{"outlinewidth":0,"ticks":""}}],"histogram2d":[{"type":"histogram2d","colorbar":{"outlinewidth":0,"ticks":""},"colorscale":[[0.0,"#0d0887"],[0.1111111111111111,"#46039f"],[0.2222222222222222,"#7201a8"],[0.3333333333333333,"#9c179e"],[0.4444444444444444,"#bd3786"],[0.5555555555555556,"#d8576b"],[0.6666666666666666,"#ed7953"],[0.7777777777777778,"#fb9f3a"],[0.8888888888888888,"#fdca26"],[1.0,"#f0f921"]]}],"heatmap":[{"type":"heatmap","colorbar":{"outlinewidth":0,"ticks":""},"colorscale":[[0.0,"#0d0887"],[0.1111111111111111,"#46039f"],[0.2222222222222222,"#7201a8"],[0.3333333333333333,"#9c179e"],[0.4444444444444444,"#bd3786"],[0.5555555555555556,"#d8576b"],[0.6666666666666666,"#ed7953"],[0.7777777777777778,"#fb9f3a"],[0.8888888888888888,"#fdca26"],[1.0,"#f0f921"]]}],"heatmapgl":[{"type":"heatmapgl","colorbar":{"outlinewidth":0,"ticks":""},"colorscale":[[0.0,"#0d0887"],[0.1111111111111111,"#46039f"],[0.2222222222222222,"#7201a8"],[0.3333333333333333,"#9c179e"],[0.4444444444444444,"#bd3786"],[0.5555555555555556,"#d8576b"],[0.6666666666666666,"#ed7953"],[0.7777777777777778,"#fb9f3a"],[0.8888888888888888,"#fdca26"],[1.0,"#f0f921"]]}],"contourcarpet":[{"type":"contourcarpet","colorbar":{"outlinewidth":0,"ticks":""}}],"contour":[{"type":"contour","colorbar":{"outlinewidth":0,"ticks":""},"colorscale":[[0.0,"#0d0887"],[0.1111111111111111,"#46039f"],[0.2222222222222222,"#7201a8"],[0.3333333333333333,"#9c179e"],[0.4444444444444444,"#bd3786"],[0.5555555555555556,"#d8576b"],[0.6666666666666666,"#ed7953"],[0.7777777777777778,"#fb9f3a"],[0.8888888888888888,"#fdca26"],[1.0,"#f0f921"]]}],"surface":[{"type":"surface","colorbar":{"outlinewidth":0,"ticks":""},"colorscale":[[0.0,"#0d0887"],[0.1111111111111111,"#46039f"],[0.2222222222222222,"#7201a8"],[0.3333333333333333,"#9c179e"],[0.4444444444444444,"#bd3786"],[0.5555555555555556,"#d8576b"],[0.6666666666666666,"#ed7953"],[0.7777777777777778,"#fb9f3a"],[0.8888888888888888,"#fdca26"],[1.0,"#f0f921"]]}],"mesh3d":[{"type":"mesh3d","colorbar":{"outlinewidth":0,"ticks":""}}],"scatter":[{"fillpattern":{"fillmode":"overlay","size":10,"solidity":0.2},"type":"scatter"}],"parcoords":[{"type":"parcoords","line":{"colorbar":{"outlinewidth":0,"ticks":""}}}],"scatterpolargl":[{"type":"scatterpolargl","marker":{"colorbar":{"outlinewidth":0,"ticks":""}}}],"bar":[{"error_x":{"color":"#2a3f5f"},"error_y":{"color":"#2a3f5f"},"marker":{"line":{"color":"#E5ECF6","width":0.5},"pattern":{"fillmode":"overlay","size":10,"solidity":0.2}},"type":"bar"}],"scattergeo":[{"type":"scattergeo","marker":{"colorbar":{"outlinewidth":0,"ticks":""}}}],"scatterpolar":[{"type":"scatterpolar","marker":{"colorbar":{"outlinewidth":0,"ticks":""}}}],"histogram":[{"marker":{"pattern":{"fillmode":"overlay","size":10,"solidity":0.2}},"type":"histogram"}],"scattergl":[{"type":"scattergl","marker":{"colorbar":{"outlinewidth":0,"ticks":""}}}],"scatter3d":[{"type":"scatter3d","line":{"colorbar":{"outlinewidth":0,"ticks":""}},"marker":{"colorbar":{"outlinewidth":0,"ticks":""}}}],"scattermapbox":[{"type":"scattermapbox","marker":{"colorbar":{"outlinewidth":0,"ticks":""}}}],"scatterternary":[{"type":"scatterternary","marker":{"colorbar":{"outlinewidth":0,"ticks":""}}}],"scattercarpet":[{"type":"scattercarpet","marker":{"colorbar":{"outlinewidth":0,"ticks":""}}}],"carpet":[{"aaxis":{"endlinecolor":"#2a3f5f","gridcolor":"white","linecolor":"white","minorgridcolor":"white","startlinecolor":"#2a3f5f"},"baxis":{"endlinecolor":"#2a3f5f","gridcolor":"white","linecolor":"white","minorgridcolor":"white","startlinecolor":"#2a3f5f"},"type":"carpet"}],"table":[{"cells":{"fill":{"color":"#EBF0F8"},"line":{"color":"white"}},"header":{"fill":{"color":"#C8D4E3"},"line":{"color":"white"}},"type":"table"}],"barpolar":[{"marker":{"line":{"color":"#E5ECF6","width":0.5},"pattern":{"fillmode":"overlay","size":10,"solidity":0.2}},"type":"barpolar"}],"pie":[{"automargin":true,"type":"pie"}]},"layout":{"autotypenumbers":"strict","colorway":["#636efa","#EF553B","#00cc96","#ab63fa","#FFA15A","#19d3f3","#FF6692","#B6E880","#FF97FF","#FECB52"],"font":{"color":"#2a3f5f"},"hovermode":"closest","hoverlabel":{"align":"left"},"paper_bgcolor":"white","plot_bgcolor":"#E5ECF6","polar":{"bgcolor":"#E5ECF6","angularaxis":{"gridcolor":"white","linecolor":"white","ticks":""},"radialaxis":{"gridcolor":"white","linecolor":"white","ticks":""}},"ternary":{"bgcolor":"#E5ECF6","aaxis":{"gridcolor":"white","linecolor":"white","ticks":""},"baxis":{"gridcolor":"white","linecolor":"white","ticks":""},"caxis":{"gridcolor":"white","linecolor":"white","ticks":""}},"coloraxis":{"colorbar":{"outlinewidth":0,"ticks":""}},"colorscale":{"sequential":[[0.0,"#0d0887"],[0.1111111111111111,"#46039f"],[0.2222222222222222,"#7201a8"],[0.3333333333333333,"#9c179e"],[0.4444444444444444,"#bd3786"],[0.5555555555555556,"#d8576b"],[0.6666666666666666,"#ed7953"],[0.7777777777777778,"#fb9f3a"],[0.8888888888888888,"#fdca26"],[1.0,"#f0f921"]],"sequentialminus":[[0.0,"#0d0887"],[0.1111111111111111,"#46039f"],[0.2222222222222222,"#7201a8"],[0.3333333333333333,"#9c179e"],[0.4444444444444444,"#bd3786"],[0.5555555555555556,"#d8576b"],[0.6666666666666666,"#ed7953"],[0.7777777777777778,"#fb9f3a"],[0.8888888888888888,"#fdca26"],[1.0,"#f0f921"]],"diverging":[[0,"#8e0152"],[0.1,"#c51b7d"],[0.2,"#de77ae"],[0.3,"#f1b6da"],[0.4,"#fde0ef"],[0.5,"#f7f7f7"],[0.6,"#e6f5d0"],[0.7,"#b8e186"],[0.8,"#7fbc41"],[0.9,"#4d9221"],[1,"#276419"]]},"xaxis":{"gridcolor":"white","linecolor":"white","ticks":"","title":{"standoff":15},"zerolinecolor":"white","automargin":true,"zerolinewidth":2},"yaxis":{"gridcolor":"white","linecolor":"white","ticks":"","title":{"standoff":15},"zerolinecolor":"white","automargin":true,"zerolinewidth":2},"scene":{"xaxis":{"backgroundcolor":"#E5ECF6","gridcolor":"white","linecolor":"white","showbackground":true,"ticks":"","zerolinecolor":"white","gridwidth":2},"yaxis":{"backgroundcolor":"#E5ECF6","gridcolor":"white","linecolor":"white","showbackground":true,"ticks":"","zerolinecolor":"white","gridwidth":2},"zaxis":{"backgroundcolor":"#E5ECF6","gridcolor":"white","linecolor":"white","showbackground":true,"ticks":"","zerolinecolor":"white","gridwidth":2}},"shapedefaults":{"line":{"color":"#2a3f5f"}},"annotationdefaults":{"arrowcolor":"#2a3f5f","arrowhead":0,"arrowwidth":1},"geo":{"bgcolor":"white","landcolor":"#E5ECF6","subunitcolor":"white","showland":true,"showlakes":true,"lakecolor":"white"},"title":{"x":0.05},"mapbox":{"style":"light"}}},"xaxis":{"anchor":"y","domain":[0.0,1.0],"title":{"text":"GDP per capita"}},"yaxis":{"anchor":"x","domain":[0.0,1.0],"title":{"text":"Investment Expenditure (as % of GDP)"}},"legend":{"title":{"text":"Income Level"},"tracegroupgap":0},"title":{"text":"Investment Expenditure (as % of GDP) vs GDP per capita (2018)"}},                        {"responsive": true}                    ).then(function(){

var gd = document.getElementById('eae1aeb7-65be-44fc-845e-359dcdfcdacd');
var x = new MutationObserver(function (mutations, observer) {{
        var display = window.getComputedStyle(gd).display;
        if (!display || display === 'none') {{
            console.log([gd, 'removed!']);
            Plotly.purge(gd);
            observer.disconnect();
        }}
}});

// Listen for the removal of the full notebook cells
var notebookContainer = gd.closest('#notebook-container');
if (notebookContainer) {{
    x.observe(notebookContainer, {childList: true});
}}

// Listen for the clearing of the current output cell
var outputEl = gd.closest('.output');
if (outputEl) {{
    x.observe(outputEl, {childList: true});
}}

                        })                };                            </script>        </div>
</body>
</html>



<html>
<head><meta charset="utf-8" /></head>
<body>
    <div>            <script src="https://cdnjs.cloudflare.com/ajax/libs/mathjax/2.7.5/MathJax.js?config=TeX-AMS-MML_SVG"></script><script type="text/javascript">if (window.MathJax && window.MathJax.Hub && window.MathJax.Hub.Config) {window.MathJax.Hub.Config({SVG: {font: "STIX-Web"}});}</script>                <script type="text/javascript">window.PlotlyConfig = {MathJaxConfig: 'local'};</script>
        <script charset="utf-8" src="https://cdn.plot.ly/plotly-2.24.1.min.js"></script>                <div id="24e9ff5f-b6f7-48eb-9596-d746d0a7bd1c" class="plotly-graph-div" style="height:525px; width:100%;"></div>            <script type="text/javascript">                                    window.PLOTLYENV=window.PLOTLYENV || {};                                    if (document.getElementById("24e9ff5f-b6f7-48eb-9596-d746d0a7bd1c")) {                    Plotly.newPlot(                        "24e9ff5f-b6f7-48eb-9596-d746d0a7bd1c",                        [{"customdata":[["Afghanistan"],["Benin"],["Burkina Faso"],["Burundi"],["Central African Republic"],["Chad"],["Ethiopia"],["Guinea"],["Guinea-Bissau"],["Haiti"],["Liberia"],["Madagascar"],["Malawi"],["Mali"],["Mozambique"],["Nepal"],["Niger"],["Rwanda"],["Sierra Leone"],["Syrian Arab Republic"],["Tajikistan"],["Togo"],["Uganda"]],"hovertemplate":"Income Level=Low income\u003cbr\u003eGDP per capita=%{x}\u003cbr\u003eNet Exports Expenditure (as % of GDP)=%{y}\u003cbr\u003eCountry Name=%{customdata[0]}\u003cextra\u003e\u003c\u002fextra\u003e","legendgroup":"Low income","marker":{"color":"#636efa","symbol":"circle"},"mode":"markers","name":"Low income","orientation":"v","showlegend":true,"x":[null,1.3045363065075943,0.9423917056106909,0.2997825084701306,0.416426157737857,0.7634076046419629,0.8424703094577008,1.1541776261411962,0.9539180675900872,1.6420406955759412,null,0.6187352659533052,null,1.1801675454169258,null,1.034949667840119,0.6888681585022614,0.9335541169168238,0.6955406414196662,1.472296369124743,0.9669804348483436,0.9618428718740492,0.8312195928096361],"xaxis":"x","y":[null,-6.592460842118117,-3.79843750909158,-12.06589142295551,-16.506193626563245,-1.7599700966657104,-13.579507799102233,-7.426145574049375,-4.702853378892187,-21.831867235240352,null,-4.129785718612228,null,-9.726905406757602,null,-35.32917082854545,-13.118195705214523,-11.75547043022118,-20.24807026452058,-17.958314416652783,-25.287036283067287,-7.966969195698267,-6.049267100920235],"yaxis":"y","type":"scatter"},{"customdata":[["Albania"],["Algeria"],["Argentina"],["Armenia"],["Azerbaijan"],["Belarus"],["Bosnia and Herzegovina"],["Botswana"],["Brazil"],["Bulgaria"],["China"],["Colombia"],["Costa Rica"],["Cuba"],["Dominica"],["Dominican Republic"],["Ecuador"],["Equatorial Guinea"],["Gabon"],["Georgia"],["Guatemala"],["Iraq"],["Jamaica"],["Jordan"],["Kazakhstan"],["Lebanon"],["Libya"],["Malaysia"],["Mauritius"],["Mexico"],["Montenegro"],["Namibia"],["Paraguay"],["Peru"],["Romania"],["Russian Federation"],["Serbia"],["South Africa"],["Sri Lanka"],["Thailand"],["Turkmenistan"]],"hovertemplate":"Income Level=Upper middle income\u003cbr\u003eGDP per capita=%{x}\u003cbr\u003eNet Exports Expenditure (as % of GDP)=%{y}\u003cbr\u003eCountry Name=%{customdata[0]}\u003cextra\u003e\u003c\u002fextra\u003e","legendgroup":"Upper middle income","marker":{"color":"#EF553B","symbol":"circle"},"mode":"markers","name":"Upper middle income","orientation":"v","showlegend":true,"x":[5.5365187015336,4.656358067756523,13.43816667529076,4.53545424780213,5.482806843127045,7.105367136361758,6.2605263652189125,9.71505031393233,10.876767251472902,10.55388901479824,11.543151777277965,8.017000102028279,14.503687986721852,11.65152806719012,null,9.131555105147369,7.4030035575351025,20.316898888639383,8.952159065170372,3.941293671607263,4.724665386900773,5.9819376990495545,6.677127903147384,5.365306694425017,9.947973864860291,8.165175918858733,15.624896937081882,12.934681764340768,12.284721444129024,11.4446752397259,10.385329667663044,6.82081880482101,6.158991030732602,7.993207106169597,14.542213099406409,13.175549950866124,8.1508594160437,8.721878107745141,4.404444202132617,8.470822302692627,null],"xaxis":"x","y":[-12.21341848174732,-5.742977771266465,-1.6507577078461837,-12.933568459580464,14.7061505443304,1.3439944326444215,-11.989730928592708,0.7757574468080756,0.3284450433604252,2.209033996889286,0.5720693768818991,-4.101476356117754,0.4582308958286392,1.515560942844128,null,-4.468489671287861,-1.015187933950605,12.597066292769345,28.545494380805597,-9.65099628174148,-9.613113099576571,15.012190183959516,-11.331023104750614,-15.702479338842974,11.533359804250344,-23.33415651909873,11.334053053670576,5.974141378041069,-5.182730093980504,-1.9172355507670336,-20.596973258127605,-7.813989005058606,1.5063658620049472,1.555512158200342,-2.953169737032894,8.592434820858646,-7.571382582716432,0.4269629744725164,-6.828514966738237,7.827896301337595,null],"yaxis":"y","type":"scatter"},{"customdata":[["Angola"],["Bangladesh"],["Cabo Verde"],["Cambodia"],["Cameroon"],["Comoros"],["Djibouti"],["El Salvador"],["Ghana"],["Honduras"],["India"],["Indonesia"],["Kenya"],["Lesotho"],["Mauritania"],["Mongolia"],["Morocco"],["Myanmar"],["Nicaragua"],["Nigeria"],["Pakistan"],["Philippines"],["Senegal"],["Tunisia"],["Ukraine"],["Uzbekistan"],["Zambia"],["Zimbabwe"]],"hovertemplate":"Income Level=Lower middle income\u003cbr\u003eGDP per capita=%{x}\u003cbr\u003eNet Exports Expenditure (as % of GDP)=%{y}\u003cbr\u003eCountry Name=%{customdata[0]}\u003cextra\u003e\u003c\u002fextra\u003e","legendgroup":"Lower middle income","marker":{"color":"#00cc96","symbol":"circle"},"mode":"markers","name":"Lower middle income","orientation":"v","showlegend":true,"x":[3.8535590703151663,1.9989045745475744,null,1.518061006773532,1.6965255969857094,1.5942202502252845,4.846573798428586,4.695081976480254,2.575051818847171,2.9848769472429204,2.2203459660510787,4.267266456476381,2.0024417354026625,1.8573921671666676,1.935872794284197,4.253117361651591,4.079512244786143,null,2.4211697513353463,null,1.769331600016486,3.470580341600621,1.5473027586138857,4.277700999187144,3.568588701314224,1.807796971100641,1.624343950010044,2.5992548853101973],"xaxis":"x","y":[13.929500660537284,-6.8785303403069005,null,-1.683963599559721,-2.783024594130597,-15.599294408443628,8.73203778022807,-15.460136528747723,-0.9838464290826028,-18.489774519843937,-3.5272271453755546,-1.0060197987578714,-8.363371252598819,-31.39590604011569,-16.05795798863928,-10.010243807420274,-8.440427587313055,null,-8.336703349652812,null,-9.573673045314116,-10.46234470815515,-14.515902601169254,-11.215209996160416,-7.284732043951547,-17.069427809462272,0.9635942526182838,-2.071627594487131],"yaxis":"y","type":"scatter"},{"customdata":[["Australia"],["Austria"],["Bahrain"],["Barbados"],["Belgium"],["Canada"],["Chile"],["Croatia"],["Cyprus"],["Denmark"],["Estonia"],["Finland"],["France"],["Germany"],["Greece"],["Hungary"],["Iceland"],["Ireland"],["Israel"],["Italy"],["Japan"],["Kuwait"],["Latvia"],["Lithuania"],["Luxembourg"],["Malta"],["Netherlands"],["New Zealand"],["Norway"],["Oman"],["Panama"],["Poland"],["Portugal"],["Puerto Rico"],["Qatar"],["Saudi Arabia"],["Seychelles"],["Singapore"],["Slovenia"],["Spain"],["Sweden"],["Switzerland"],["Trinidad and Tobago"],["United Arab Emirates"],["United Kingdom"],["United States"],["Uruguay"]],"hovertemplate":"Income Level=High income\u003cbr\u003eGDP per capita=%{x}\u003cbr\u003eNet Exports Expenditure (as % of GDP)=%{y}\u003cbr\u003eCountry Name=%{customdata[0]}\u003cextra\u003e\u003c\u002fextra\u003e","legendgroup":"High income","marker":{"color":"#ab63fa","symbol":"circle"},"mode":"markers","name":"High income","orientation":"v","showlegend":true,"x":[68.92380225582335,60.22665665211098,26.36956722236935,19.824924692373035,57.68378367988274,55.63555110471394,18.01217512805355,19.065584831786992,28.55178058696604,76.00629771784118,28.01822462101277,60.83959658667786,50.926428954480215,56.2160279207692,23.42278611341433,19.322318189192536,92.26640606413878,88.76210929938102,53.980370920364,40.90619262622918,47.74192480394642,null,20.86504572808823,22.45774398827238,135.03389024507197,36.30902284819293,65.68873805572721,51.55460942711251,98.64377489854924,23.312104382606304,null,17.636314749583878,27.548883136669264,33.667706137206466,null,30.01028424970493,20.49769509749656,66.8551394051294,30.48046667854283,35.31277554830795,68.3609054340486,93.86419816759827,null,46.363776580562345,50.915604206352434,71.19717335877542,null],"xaxis":"x","y":[0.300479654391841,2.549349953578824,6.968465829491331,1.1993874004095468,-0.2765004033939518,-1.624545910058876,-0.9841071069466554,-0.7116398180185701,1.233795659421579,4.979290911988314,2.307624972998048,-1.0308117334459563,-0.8262964592830004,5.123016553569371,-1.837611183439161,3.613608254824984,2.7904059566340846,25.48183170756005,0.7026522863625634,2.033474158629078,0.0167459019642753,null,-0.6035473681042292,1.5527522969817835,28.09425562623129,16.29061559214002,8.514192233135306,-0.0388242895848306,5.403528926199649,9.938398551220812,null,1.779741493765237,0.3981416171539158,12.65739592959048,null,10.525885395614573,-10.688383218124857,27.73760561760057,7.261418330080587,2.30718681599467,1.7846469654105035,9.388719396912972,null,24.961601390305947,-1.16802682606748,-2.540934473780597,null],"yaxis":"y","type":"scatter"}],                        {"template":{"data":{"histogram2dcontour":[{"type":"histogram2dcontour","colorbar":{"outlinewidth":0,"ticks":""},"colorscale":[[0.0,"#0d0887"],[0.1111111111111111,"#46039f"],[0.2222222222222222,"#7201a8"],[0.3333333333333333,"#9c179e"],[0.4444444444444444,"#bd3786"],[0.5555555555555556,"#d8576b"],[0.6666666666666666,"#ed7953"],[0.7777777777777778,"#fb9f3a"],[0.8888888888888888,"#fdca26"],[1.0,"#f0f921"]]}],"choropleth":[{"type":"choropleth","colorbar":{"outlinewidth":0,"ticks":""}}],"histogram2d":[{"type":"histogram2d","colorbar":{"outlinewidth":0,"ticks":""},"colorscale":[[0.0,"#0d0887"],[0.1111111111111111,"#46039f"],[0.2222222222222222,"#7201a8"],[0.3333333333333333,"#9c179e"],[0.4444444444444444,"#bd3786"],[0.5555555555555556,"#d8576b"],[0.6666666666666666,"#ed7953"],[0.7777777777777778,"#fb9f3a"],[0.8888888888888888,"#fdca26"],[1.0,"#f0f921"]]}],"heatmap":[{"type":"heatmap","colorbar":{"outlinewidth":0,"ticks":""},"colorscale":[[0.0,"#0d0887"],[0.1111111111111111,"#46039f"],[0.2222222222222222,"#7201a8"],[0.3333333333333333,"#9c179e"],[0.4444444444444444,"#bd3786"],[0.5555555555555556,"#d8576b"],[0.6666666666666666,"#ed7953"],[0.7777777777777778,"#fb9f3a"],[0.8888888888888888,"#fdca26"],[1.0,"#f0f921"]]}],"heatmapgl":[{"type":"heatmapgl","colorbar":{"outlinewidth":0,"ticks":""},"colorscale":[[0.0,"#0d0887"],[0.1111111111111111,"#46039f"],[0.2222222222222222,"#7201a8"],[0.3333333333333333,"#9c179e"],[0.4444444444444444,"#bd3786"],[0.5555555555555556,"#d8576b"],[0.6666666666666666,"#ed7953"],[0.7777777777777778,"#fb9f3a"],[0.8888888888888888,"#fdca26"],[1.0,"#f0f921"]]}],"contourcarpet":[{"type":"contourcarpet","colorbar":{"outlinewidth":0,"ticks":""}}],"contour":[{"type":"contour","colorbar":{"outlinewidth":0,"ticks":""},"colorscale":[[0.0,"#0d0887"],[0.1111111111111111,"#46039f"],[0.2222222222222222,"#7201a8"],[0.3333333333333333,"#9c179e"],[0.4444444444444444,"#bd3786"],[0.5555555555555556,"#d8576b"],[0.6666666666666666,"#ed7953"],[0.7777777777777778,"#fb9f3a"],[0.8888888888888888,"#fdca26"],[1.0,"#f0f921"]]}],"surface":[{"type":"surface","colorbar":{"outlinewidth":0,"ticks":""},"colorscale":[[0.0,"#0d0887"],[0.1111111111111111,"#46039f"],[0.2222222222222222,"#7201a8"],[0.3333333333333333,"#9c179e"],[0.4444444444444444,"#bd3786"],[0.5555555555555556,"#d8576b"],[0.6666666666666666,"#ed7953"],[0.7777777777777778,"#fb9f3a"],[0.8888888888888888,"#fdca26"],[1.0,"#f0f921"]]}],"mesh3d":[{"type":"mesh3d","colorbar":{"outlinewidth":0,"ticks":""}}],"scatter":[{"fillpattern":{"fillmode":"overlay","size":10,"solidity":0.2},"type":"scatter"}],"parcoords":[{"type":"parcoords","line":{"colorbar":{"outlinewidth":0,"ticks":""}}}],"scatterpolargl":[{"type":"scatterpolargl","marker":{"colorbar":{"outlinewidth":0,"ticks":""}}}],"bar":[{"error_x":{"color":"#2a3f5f"},"error_y":{"color":"#2a3f5f"},"marker":{"line":{"color":"#E5ECF6","width":0.5},"pattern":{"fillmode":"overlay","size":10,"solidity":0.2}},"type":"bar"}],"scattergeo":[{"type":"scattergeo","marker":{"colorbar":{"outlinewidth":0,"ticks":""}}}],"scatterpolar":[{"type":"scatterpolar","marker":{"colorbar":{"outlinewidth":0,"ticks":""}}}],"histogram":[{"marker":{"pattern":{"fillmode":"overlay","size":10,"solidity":0.2}},"type":"histogram"}],"scattergl":[{"type":"scattergl","marker":{"colorbar":{"outlinewidth":0,"ticks":""}}}],"scatter3d":[{"type":"scatter3d","line":{"colorbar":{"outlinewidth":0,"ticks":""}},"marker":{"colorbar":{"outlinewidth":0,"ticks":""}}}],"scattermapbox":[{"type":"scattermapbox","marker":{"colorbar":{"outlinewidth":0,"ticks":""}}}],"scatterternary":[{"type":"scatterternary","marker":{"colorbar":{"outlinewidth":0,"ticks":""}}}],"scattercarpet":[{"type":"scattercarpet","marker":{"colorbar":{"outlinewidth":0,"ticks":""}}}],"carpet":[{"aaxis":{"endlinecolor":"#2a3f5f","gridcolor":"white","linecolor":"white","minorgridcolor":"white","startlinecolor":"#2a3f5f"},"baxis":{"endlinecolor":"#2a3f5f","gridcolor":"white","linecolor":"white","minorgridcolor":"white","startlinecolor":"#2a3f5f"},"type":"carpet"}],"table":[{"cells":{"fill":{"color":"#EBF0F8"},"line":{"color":"white"}},"header":{"fill":{"color":"#C8D4E3"},"line":{"color":"white"}},"type":"table"}],"barpolar":[{"marker":{"line":{"color":"#E5ECF6","width":0.5},"pattern":{"fillmode":"overlay","size":10,"solidity":0.2}},"type":"barpolar"}],"pie":[{"automargin":true,"type":"pie"}]},"layout":{"autotypenumbers":"strict","colorway":["#636efa","#EF553B","#00cc96","#ab63fa","#FFA15A","#19d3f3","#FF6692","#B6E880","#FF97FF","#FECB52"],"font":{"color":"#2a3f5f"},"hovermode":"closest","hoverlabel":{"align":"left"},"paper_bgcolor":"white","plot_bgcolor":"#E5ECF6","polar":{"bgcolor":"#E5ECF6","angularaxis":{"gridcolor":"white","linecolor":"white","ticks":""},"radialaxis":{"gridcolor":"white","linecolor":"white","ticks":""}},"ternary":{"bgcolor":"#E5ECF6","aaxis":{"gridcolor":"white","linecolor":"white","ticks":""},"baxis":{"gridcolor":"white","linecolor":"white","ticks":""},"caxis":{"gridcolor":"white","linecolor":"white","ticks":""}},"coloraxis":{"colorbar":{"outlinewidth":0,"ticks":""}},"colorscale":{"sequential":[[0.0,"#0d0887"],[0.1111111111111111,"#46039f"],[0.2222222222222222,"#7201a8"],[0.3333333333333333,"#9c179e"],[0.4444444444444444,"#bd3786"],[0.5555555555555556,"#d8576b"],[0.6666666666666666,"#ed7953"],[0.7777777777777778,"#fb9f3a"],[0.8888888888888888,"#fdca26"],[1.0,"#f0f921"]],"sequentialminus":[[0.0,"#0d0887"],[0.1111111111111111,"#46039f"],[0.2222222222222222,"#7201a8"],[0.3333333333333333,"#9c179e"],[0.4444444444444444,"#bd3786"],[0.5555555555555556,"#d8576b"],[0.6666666666666666,"#ed7953"],[0.7777777777777778,"#fb9f3a"],[0.8888888888888888,"#fdca26"],[1.0,"#f0f921"]],"diverging":[[0,"#8e0152"],[0.1,"#c51b7d"],[0.2,"#de77ae"],[0.3,"#f1b6da"],[0.4,"#fde0ef"],[0.5,"#f7f7f7"],[0.6,"#e6f5d0"],[0.7,"#b8e186"],[0.8,"#7fbc41"],[0.9,"#4d9221"],[1,"#276419"]]},"xaxis":{"gridcolor":"white","linecolor":"white","ticks":"","title":{"standoff":15},"zerolinecolor":"white","automargin":true,"zerolinewidth":2},"yaxis":{"gridcolor":"white","linecolor":"white","ticks":"","title":{"standoff":15},"zerolinecolor":"white","automargin":true,"zerolinewidth":2},"scene":{"xaxis":{"backgroundcolor":"#E5ECF6","gridcolor":"white","linecolor":"white","showbackground":true,"ticks":"","zerolinecolor":"white","gridwidth":2},"yaxis":{"backgroundcolor":"#E5ECF6","gridcolor":"white","linecolor":"white","showbackground":true,"ticks":"","zerolinecolor":"white","gridwidth":2},"zaxis":{"backgroundcolor":"#E5ECF6","gridcolor":"white","linecolor":"white","showbackground":true,"ticks":"","zerolinecolor":"white","gridwidth":2}},"shapedefaults":{"line":{"color":"#2a3f5f"}},"annotationdefaults":{"arrowcolor":"#2a3f5f","arrowhead":0,"arrowwidth":1},"geo":{"bgcolor":"white","landcolor":"#E5ECF6","subunitcolor":"white","showland":true,"showlakes":true,"lakecolor":"white"},"title":{"x":0.05},"mapbox":{"style":"light"}}},"xaxis":{"anchor":"y","domain":[0.0,1.0],"title":{"text":"GDP per capita"}},"yaxis":{"anchor":"x","domain":[0.0,1.0],"title":{"text":"Net Exports Expenditure (as % of GDP)"}},"legend":{"title":{"text":"Income Level"},"tracegroupgap":0},"title":{"text":"Net Exports Expenditure (as % of GDP) vs GDP per capita (2018)"}},                        {"responsive": true}                    ).then(function(){

var gd = document.getElementById('24e9ff5f-b6f7-48eb-9596-d746d0a7bd1c');
var x = new MutationObserver(function (mutations, observer) {{
        var display = window.getComputedStyle(gd).display;
        if (!display || display === 'none') {{
            console.log([gd, 'removed!']);
            Plotly.purge(gd);
            observer.disconnect();
        }}
}});

// Listen for the removal of the full notebook cells
var notebookContainer = gd.closest('#notebook-container');
if (notebookContainer) {{
    x.observe(notebookContainer, {childList: true});
}}

// Listen for the clearing of the current output cell
var outputEl = gd.closest('.output');
if (outputEl) {{
    x.observe(outputEl, {childList: true});
}}

                        })                };                            </script>        </div>
</body>
</html>


## 2.0 GDP: Unique Factors
Now we will explore the correlations between GDP and other socioeconomic, health and technological indicators. GDP per capita is a common proxy for understanding the standards of living in other countries, as economic health often allows other facets of a country's overall health - such as healthcare and education - to flourish. However, GDP in itself does not directly measure many important quality of life metrics such as equality of opportunity, happiness or sustainability, and as such we must be critical when generalising the standards of living in a country from GDP alone.


```python
# Import data
data_hdi = pd.read_excel('GDP_HDI.xlsx')
data_gni = pd.read_excel('GDP_GNI.xlsx')
data_lifeexp = pd.read_excel('GDP_LIFEEXP.xlsx')
data_education = pd.read_excel('GDP_SCHOOLING.xlsx')
data_energy = pd.read_excel('GDP_ENERGY.xlsx')
data_mortality = pd.read_excel('GDP_MORTALITY.xlsx')
data_gini = pd.read_excel('GDP_GINI.xlsx')
```

### 3.1 Development: **Human Development Index (HDI)**
The first facet we will explore is the relationship between GDP per capita and HDI (Human Development Index). [Click here](https://ourworldindata.org/grapher/human-development-index-vs-gdp-per-capita) to access the GDP per capita vs. HDI data (from Our World in Data).

We will plot both the raw data as well as the data with a logarithmic line of best fit.


```python
params, _ = scipy.optimize.curve_fit(lambda t,a,b: a+b*np.log(t),  data_hdi.gdppc,  data_hdi.HDI)
params
```




    array([-0.42581573,  0.1226807 ])




```python
gdppc_ind = data_hdi.gdppc.argsort()
sorted_gdppc = data_hdi.gdppc[gdppc_ind]
sorted_hdi = data_hdi.HDI[gdppc_ind]

hdi_bestfit = -0.426 + 0.123*np.log(sorted_gdppc)


fig, ax = plt.subplots(nrows=1, ncols=2, dpi=150, sharey=True)

ax[0].plot(data_hdi.gdppc, data_hdi.HDI, 'bo', mfc='none')
ax[0].set_ylabel('HDI')
ax[0].set_xscale("log")
ax[1].plot(sorted_gdppc, sorted_hdi, 'bo', mfc='none',label="Data")
ax[1].plot(sorted_gdppc, hdi_bestfit,'--r',label="Fit")
ax[1].set_xscale("log")
ax[1].legend()
fig.text(0.35, 0, 'GDP per capita (international $)', va='center', rotation='horizontal')
fig.tight_layout()
```


    
![png](Why_GDP_lecture_files/Why_GDP_lecture_33_0.png)
    


With the logarithmic line of best fit, we can see clearly that HDI rises approximately logarithmically with GDP per capita. GDP per capita is very closely related to GNI (gross national income) per capita in both definition and calculation, and GNI per capita is one of the four quantitative factors that contribute to a country's HDI measurement. In fact, the correlation between GDP per capita and HDI is so strong in the figure above that we may (correctly) assume that the log of GNI is used in the [HDI calculation](https://hdr.undp.org/system/files/documents/technical-notes-calculating-human-development-indices.pdf) (to reflect the diminishing importance of income with increasing GNI).

### 3.2 Income: **Gross National Income (GNI)**
Access the GNI data [here](https://ourworldindata.org/grapher/gni-per-capita-vs-gdp-per-capita) from Our World in Data.


```python
# Visualise the relationship between GDP and GNI
fig, ax = plt.subplots(dpi=100)
ax.plot(data_gni.gdppc, data_gni.gni, 'ro', mfc='none')
ax.set_xlabel('GDP per capita (international $)')
ax.set_ylabel('GNI per capita (international $)')
plt.show()
```


    
![png](Why_GDP_lecture_files/Why_GDP_lecture_35_0.png)
    


### 3.3 Health: **Average life expectancy at birth**
Access the life expectancy data [here](https://ourworldindata.org/grapher/life-expectancy-vs-gdp-per-capita?tab=table&time=2019) from Our World in Data.


```python
# Visualise the relationship between GDP and life expectancy
fig, ax = plt.subplots(dpi=100)
ax.plot(data_lifeexp.gdppc, data_lifeexp.life_exp, 'mo', mfc='none')
ax.set_xlabel('GDP per capita (international $)')
ax.set_ylabel('Average life expectancy (years)')
plt.show()
```


    
![png](Why_GDP_lecture_files/Why_GDP_lecture_37_0.png)
    


It appears like there is a very high linear correlation between GDP per capita and average life expectancy for low-income countries, but almost no correlation at all for high-income countries. To investigate this, we can break up the data into lower-income and higher-income (truncated at a GDP per capita of 28,000 international $).


```python
gdppc_lowincome = []; lifeexp_lowincome = [];
gdppc_highincome = []; lifeexp_highincome = [];

for i in range(len(data_lifeexp.gdppc)):
    if data_lifeexp.gdppc[i] < 28000:
        gdppc_lowincome.append(data_lifeexp.gdppc[i])
        lifeexp_lowincome.append(data_lifeexp.life_exp[i])
    else:
        gdppc_highincome.append(data_lifeexp.gdppc[i])
        lifeexp_highincome.append(data_lifeexp.life_exp[i])

fig, ax = plt.subplots(nrows=2, ncols=1, dpi=120, sharey=True)
ax[0].plot(gdppc_lowincome, lifeexp_lowincome, 'mo', mfc='none',label="Data")
ax[1].plot(gdppc_highincome, lifeexp_highincome, 'mo', mfc='none',label="Data")
ax[1].set_xlabel('GDP per capita (international $)')
ax[0].set_title('Low income')
ax[1].set_title('High income')
fig.text(-0.02, 0.5, 'Average life expectancy (years)', va='center', rotation='vertical')
fig.tight_layout()

plt.show()
```


    
![png](Why_GDP_lecture_files/Why_GDP_lecture_39_0.png)
    


We can see that there is a steadily-increasing relationship between GDP per capita and average life expectancy for low-income countries, and, as expected, almost no correlation at all for high-income countries. This is likely because many premature deaths in low-income countries are caused by preventable diseases such as malaria, HIV/AIDS, cholera and tuberculosis. Small increases in GDP per capita for low-income countries can provide individuals with improved accessibility and availability of treatments for these preventable diseases. For example, malaria treatment in Nigeria costs on average [32 USD per case](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC5691839/), which requires a relatively small increase in GDP per capita for potentially life-saving treatment. Deaths in higher-income countries are often caused by non-preventable and/or lifestyle diseases (such as heart disease or cancer), which currently present the "biological limit" for humans (life expectancy of ~85 years).

### 3.4 Education: Average years of schooling
Access the mean number of schooling years data [here](https://ourworldindata.org/grapher/average-years-of-schooling-vs-gdp-per-capita) from Our World in Data.


```python
# Visualise relationship between energy consumption and GDP
fig, ax = plt.subplots(dpi=100)
ax.plot(data_education.gdppc, data_education.schooling, 'yo', mfc='none')
ax.set_xlabel('GDP per capita (international $)')
ax.set_ylabel('Average years of schooling')
ax.set_xscale("log")
plt.show()
```


    
![png](Why_GDP_lecture_files/Why_GDP_lecture_41_0.png)
    


We can see that the relationship is fairly weak and especially poorly correlated for high-income countries (GDP per capita above 50,000 international $). Hence, above a certain GDP per capita, further expenditures on schooling do not neccessarily lead to a more educated population. We can visualise this by plotting the correlation for low-income and high-income countries.


```python
gdppc_lowincome = []; education_lowincome = [];
gdppc_highincome = []; education_highincome = [];

for i in range(len(data_education.gdppc)):
    if data_education.gdppc[i] < 28000:
        gdppc_lowincome.append(data_education.gdppc[i])
        education_lowincome.append(data_education.schooling[i])
    else:
        gdppc_highincome.append(data_education.gdppc[i])
        education_highincome.append(data_education.schooling[i])

fig, ax = plt.subplots(nrows=2, ncols=1, dpi=120, sharey=True)
ax[0].plot(gdppc_lowincome, education_lowincome, 'yo', mfc='none',label="Data")
ax[1].plot(gdppc_highincome, education_highincome, 'yo', mfc='none',label="Data")
ax[1].set_xlabel('GDP per capita (international $)')
ax[0].set_title('Low income')
ax[1].set_title('High income')
fig.text(-0.02, 0.5, 'Average years of schooling', va='center', rotation='vertical')
fig.tight_layout()

plt.show()
```


    
![png](Why_GDP_lecture_files/Why_GDP_lecture_43_0.png)
    


### 3.5 Energy: **Primary energy consumption**
The energy consumption against GDP per capita data is available from [Our World in Data](https://ourworldindata.org/grapher/energy-use-per-person-vs-gdp-per-capita). We will plot both the raw data as well as the data with a linear line of best fit.


```python
params, _ = scipy.optimize.curve_fit(lambda t,a,b: a+b*t,  data_energy.gdppc,  data_energy.eupc)
params
```




    array([2.32370329e+03, 1.20148788e+00])




```python
gdppc_ind = data_energy.gdppc.argsort()
sorted_gdppc = data_energy.gdppc[gdppc_ind]
sorted_energy = data_energy.eupc[gdppc_ind]

energy_bestfit = 2323.7 + 1.2*sorted_gdppc

fig, ax = plt.subplots(nrows=1, ncols=2, dpi=150, sharey=True)

ax[0].plot(data_energy.gdppc, data_energy.eupc, 'go', mfc='none')
ax[0].set_ylabel('Primary energy consumption per capita (kWh)')
ax[0].set_yscale("log")
ax[1].plot(data_energy.gdppc, data_energy.eupc, 'go', mfc='none',label="Data")
ax[1].plot(sorted_gdppc, energy_bestfit,'--r',label="Fit")
ax[1].set_yscale("log")
ax[1].legend()
fig.text(0.35, 0, 'GDP per capita (international $)', va='center', rotation='horizontal')
fig.tight_layout()
plt.show()
```


    
![png](Why_GDP_lecture_files/Why_GDP_lecture_46_0.png)
    


We can add a residuals plot to extract information from the deviation from the line of best fit.


```python
gdppc_energy_residual = sorted_energy - energy_bestfit

fig, ax = plt.subplots(dpi=100)
ax.stem(sorted_gdppc, gdppc_energy_residual, 'bo')
ax.set_xlabel('GDP per capita (international $)')
ax.set_ylabel('Residual against line of best fit')
plt.show()
```


    
![png](Why_GDP_lecture_files/Why_GDP_lecture_48_0.png)
    


We can make some generalisations from this residuals plot. In general, the line of best fit tends to overestimate the true energy consumption per capita, which is likely due to several outstanding outliers in very high energy use for relatively low GDP per capita (Turkmenistan, Iceland, Russia, Kazakstan, UAE, Kuwait, Oman, Trinidad and Tobago). These countries are all rich in natural gas and oil, so we can see that the effect of GDP per capita on energy use may be overshadowed by natural resource abundance and quality (as well as government regulation).

### 3.6 Infant mortality: Child mortality rate
One further factor that we can investigate is the correlation between GDP per capita and child mortality rate (which is the number of infants whom die before the age of five). The data is available from [Our World in Data](https://ourworldindata.org/grapher/child-mortality-gdp-per-capita?tab=table&time=2018).


```python
# Visualise relationship between GDP and child mortality rate
fig, ax = plt.subplots(dpi=100)
ax.plot(data_mortality.gdppc, data_mortality.rate, 'bo', mfc='none')
ax.set_xlabel('GDP per capita (international $)')
ax.set_ylabel('Child mortality rate (%)')
ax.set_yscale("log")
ax.set_xscale("log")
plt.show()
```


    
![png](Why_GDP_lecture_files/Why_GDP_lecture_50_0.png)
    


From this data, we can see that, in general, child mortality decreases with increasing GDP per capita approximately  exponentially. This relationship is to be expected - better economic conditions create better health outcomes through better health care, more nutritious diets, and better health-related knowledge. Additionally, access to health personnel and health facilities such as midwifes, doctors, health posts and clinics would increase with higher GDP per capita, leading to less birth fatalities.

## 4. GDP and Enviroment


GDP sometimes disregards for the environmental costs of economic activities. GDP measures the market value of goods and services produced within a country without subtracting the negative externalities, such as:
- Pollution
- Resource depletion
- Global Warming
- Loss of biodiversity


This oversight means activities harming the environment can actually contribute to GDP growth, creating a perverse incentive structure that rewards short-term economic gains at the expense of long-term sustainability.  

### 4.1. Temperature Anomaly vs. World GDP

Consider the following diagram of Temperature Anomaly vs. World GDP


```python
data = pd.read_excel('Global temp.xlsx', sheet_name='Temperature Anomaly')

plt.figure(figsize=(10, 6))

ax1 = plt.gca()
ax1.plot(data['Year'], data['gdppc'], label='GDP per capita', color='blue', marker='o')
ax1.set_xlabel('Year')
ax1.set_ylabel('GDP per Capita', color='blue')

ax2 = ax1.twinx()
ax2.plot(data['Year'], data['Anomaly'], label='Temperature Anomaly', color='red', marker='x')
ax2.set_ylabel('Temperature Anomaly', color='red')

plt.title('GDP per Capita and Temperature Anomaly vs. Year')

# Show the plot
plt.show()

```


    
![png](Why_GDP_lecture_files/Why_GDP_lecture_55_0.png)
    


Temperature anomaly measures the difference between the temperature of the current year and the long-term average. A positive figure indicates that the temperature was warmer than the average value, and vice versa.

From 1850 to 2023, as GDP per Capita increases the golbal Temperature Anomaly increases as well. The relationship can be seen more clearly by plotting World GDP against Temperature Anomaly:


```python
data = pd.read_excel('GDP.xlsx', sheet_name='Temperature')

fig = px.scatter(data, x='World GDP', y='Temperature Anomaly',
                 hover_name='Year', title='Temperature Anomaly vs. World GDP')


fig.update_layout(
    xaxis_title="GDP ($ trillions)",
    yaxis_title="Temperature Anomaly(Degree C)",
    xaxis_gridcolor='lightgrey',
    yaxis_gridcolor='lightgrey',
)

fig.show()
```


<html>
<head><meta charset="utf-8" /></head>
<body>
    <div>            <script src="https://cdnjs.cloudflare.com/ajax/libs/mathjax/2.7.5/MathJax.js?config=TeX-AMS-MML_SVG"></script><script type="text/javascript">if (window.MathJax && window.MathJax.Hub && window.MathJax.Hub.Config) {window.MathJax.Hub.Config({SVG: {font: "STIX-Web"}});}</script>                <script type="text/javascript">window.PlotlyConfig = {MathJaxConfig: 'local'};</script>
        <script charset="utf-8" src="https://cdn.plot.ly/plotly-2.24.1.min.js"></script>                <div id="97e5b2d8-50bd-4797-9bb4-865ffcfc5781" class="plotly-graph-div" style="height:525px; width:100%;"></div>            <script type="text/javascript">                                    window.PLOTLYENV=window.PLOTLYENV || {};                                    if (document.getElementById("97e5b2d8-50bd-4797-9bb4-865ffcfc5781")) {                    Plotly.newPlot(                        "97e5b2d8-50bd-4797-9bb4-865ffcfc5781",                        [{"hovertemplate":"\u003cb\u003e%{hovertext}\u003c\u002fb\u003e\u003cbr\u003e\u003cbr\u003eWorld GDP=%{x}\u003cbr\u003eTemperature Anomaly=%{y}\u003cextra\u003e\u003c\u002fextra\u003e","hovertext":[1960.0,1961.0,1962.0,1963.0,1964.0,1965.0,1966.0,1967.0,1968.0,1969.0,1970.0,1971.0,1972.0,1973.0,1974.0,1975.0,1976.0,1977.0,1978.0,1979.0,1980.0,1981.0,1982.0,1983.0,1984.0,1985.0,1986.0,1987.0,1988.0,1989.0,1990.0,1991.0,1992.0,1993.0,1994.0,1995.0,1996.0,1997.0,1998.0,1999.0,2000.0,2001.0,2002.0,2003.0,2004.0,2005.0,2006.0,2007.0,2008.0,2009.0,2010.0,2011.0,2012.0,2013.0,2014.0,2015.0,2016.0,2017.0,2018.0,2019.0,2020.0,2021.0,2022.0],"legendgroup":"","marker":{"color":"#636efa","symbol":"circle"},"mode":"markers","name":"","orientation":"v","showlegend":false,"x":[1381135479871.2927,1446355951851.148,1546369168288.8157,1670666024902.5203,1832615520368.0493,1994519203522.5742,2161644938244.9246,2308597009339.407,2491804907882.135,2745215843083.188,3009970148766.3477,3323043011474.5327,3835299184390.582,4655916456683.006,5333766079846.988,5965065154144.336,6480247175250.142,7329899696227.952,8738280397493.851,10163180097207.06,11495788728590.51,11853208811986.824,11684061489731.629,12000649159392.398,12460879740359.88,12977172366636.71,15348791135000.639,17551012270510.068,19641101601883.32,20434564489549.066,22935041260489.773,23932506768140.375,25623906924793.227,26235071296754.44,27997506090383.188,31175460550855.953,31899770175146.74,31797633354814.906,31748589989088.242,32784571900951.004,33898969364124.95,33689211605170.5,34982494436235.895,39219228352279.805,44195418733419.09,47859243040843.6,51862621936457.3,58446784384979.03,64227645495873.88,60885970983756.07,66707071764655.234,73965141177386.45,75612548773168.38,77714723867935.44,79837156825125.53,75283270551825.56,76518978973625.19,81484101071460.52,86542678179030.55,87777403956321.14,85257737349905.5,97529676807424.83,101325686724630.19],"xaxis":"x","y":[-0.03,0.06,0.03,0.05,-0.2,-0.11,-0.06,-0.02,-0.08,0.05,0.03,-0.08,0.01,0.16,-0.07,-0.01,-0.1,0.18,0.07,0.16,0.26,0.32,0.14,0.31,0.16,0.12,0.18,0.32,0.39,0.27,0.45,0.4,0.22,0.23,0.31,0.45,0.33,0.46,0.61,0.38,0.39,0.53,0.63,0.62,0.53,0.67,0.63,0.66,0.54,0.65,0.72,0.61,0.65,0.67,0.74,0.9,1.01,0.92,0.85,0.97,1.02,0.85,0.89],"yaxis":"y","type":"scatter"}],                        {"template":{"data":{"histogram2dcontour":[{"type":"histogram2dcontour","colorbar":{"outlinewidth":0,"ticks":""},"colorscale":[[0.0,"#0d0887"],[0.1111111111111111,"#46039f"],[0.2222222222222222,"#7201a8"],[0.3333333333333333,"#9c179e"],[0.4444444444444444,"#bd3786"],[0.5555555555555556,"#d8576b"],[0.6666666666666666,"#ed7953"],[0.7777777777777778,"#fb9f3a"],[0.8888888888888888,"#fdca26"],[1.0,"#f0f921"]]}],"choropleth":[{"type":"choropleth","colorbar":{"outlinewidth":0,"ticks":""}}],"histogram2d":[{"type":"histogram2d","colorbar":{"outlinewidth":0,"ticks":""},"colorscale":[[0.0,"#0d0887"],[0.1111111111111111,"#46039f"],[0.2222222222222222,"#7201a8"],[0.3333333333333333,"#9c179e"],[0.4444444444444444,"#bd3786"],[0.5555555555555556,"#d8576b"],[0.6666666666666666,"#ed7953"],[0.7777777777777778,"#fb9f3a"],[0.8888888888888888,"#fdca26"],[1.0,"#f0f921"]]}],"heatmap":[{"type":"heatmap","colorbar":{"outlinewidth":0,"ticks":""},"colorscale":[[0.0,"#0d0887"],[0.1111111111111111,"#46039f"],[0.2222222222222222,"#7201a8"],[0.3333333333333333,"#9c179e"],[0.4444444444444444,"#bd3786"],[0.5555555555555556,"#d8576b"],[0.6666666666666666,"#ed7953"],[0.7777777777777778,"#fb9f3a"],[0.8888888888888888,"#fdca26"],[1.0,"#f0f921"]]}],"heatmapgl":[{"type":"heatmapgl","colorbar":{"outlinewidth":0,"ticks":""},"colorscale":[[0.0,"#0d0887"],[0.1111111111111111,"#46039f"],[0.2222222222222222,"#7201a8"],[0.3333333333333333,"#9c179e"],[0.4444444444444444,"#bd3786"],[0.5555555555555556,"#d8576b"],[0.6666666666666666,"#ed7953"],[0.7777777777777778,"#fb9f3a"],[0.8888888888888888,"#fdca26"],[1.0,"#f0f921"]]}],"contourcarpet":[{"type":"contourcarpet","colorbar":{"outlinewidth":0,"ticks":""}}],"contour":[{"type":"contour","colorbar":{"outlinewidth":0,"ticks":""},"colorscale":[[0.0,"#0d0887"],[0.1111111111111111,"#46039f"],[0.2222222222222222,"#7201a8"],[0.3333333333333333,"#9c179e"],[0.4444444444444444,"#bd3786"],[0.5555555555555556,"#d8576b"],[0.6666666666666666,"#ed7953"],[0.7777777777777778,"#fb9f3a"],[0.8888888888888888,"#fdca26"],[1.0,"#f0f921"]]}],"surface":[{"type":"surface","colorbar":{"outlinewidth":0,"ticks":""},"colorscale":[[0.0,"#0d0887"],[0.1111111111111111,"#46039f"],[0.2222222222222222,"#7201a8"],[0.3333333333333333,"#9c179e"],[0.4444444444444444,"#bd3786"],[0.5555555555555556,"#d8576b"],[0.6666666666666666,"#ed7953"],[0.7777777777777778,"#fb9f3a"],[0.8888888888888888,"#fdca26"],[1.0,"#f0f921"]]}],"mesh3d":[{"type":"mesh3d","colorbar":{"outlinewidth":0,"ticks":""}}],"scatter":[{"fillpattern":{"fillmode":"overlay","size":10,"solidity":0.2},"type":"scatter"}],"parcoords":[{"type":"parcoords","line":{"colorbar":{"outlinewidth":0,"ticks":""}}}],"scatterpolargl":[{"type":"scatterpolargl","marker":{"colorbar":{"outlinewidth":0,"ticks":""}}}],"bar":[{"error_x":{"color":"#2a3f5f"},"error_y":{"color":"#2a3f5f"},"marker":{"line":{"color":"#E5ECF6","width":0.5},"pattern":{"fillmode":"overlay","size":10,"solidity":0.2}},"type":"bar"}],"scattergeo":[{"type":"scattergeo","marker":{"colorbar":{"outlinewidth":0,"ticks":""}}}],"scatterpolar":[{"type":"scatterpolar","marker":{"colorbar":{"outlinewidth":0,"ticks":""}}}],"histogram":[{"marker":{"pattern":{"fillmode":"overlay","size":10,"solidity":0.2}},"type":"histogram"}],"scattergl":[{"type":"scattergl","marker":{"colorbar":{"outlinewidth":0,"ticks":""}}}],"scatter3d":[{"type":"scatter3d","line":{"colorbar":{"outlinewidth":0,"ticks":""}},"marker":{"colorbar":{"outlinewidth":0,"ticks":""}}}],"scattermapbox":[{"type":"scattermapbox","marker":{"colorbar":{"outlinewidth":0,"ticks":""}}}],"scatterternary":[{"type":"scatterternary","marker":{"colorbar":{"outlinewidth":0,"ticks":""}}}],"scattercarpet":[{"type":"scattercarpet","marker":{"colorbar":{"outlinewidth":0,"ticks":""}}}],"carpet":[{"aaxis":{"endlinecolor":"#2a3f5f","gridcolor":"white","linecolor":"white","minorgridcolor":"white","startlinecolor":"#2a3f5f"},"baxis":{"endlinecolor":"#2a3f5f","gridcolor":"white","linecolor":"white","minorgridcolor":"white","startlinecolor":"#2a3f5f"},"type":"carpet"}],"table":[{"cells":{"fill":{"color":"#EBF0F8"},"line":{"color":"white"}},"header":{"fill":{"color":"#C8D4E3"},"line":{"color":"white"}},"type":"table"}],"barpolar":[{"marker":{"line":{"color":"#E5ECF6","width":0.5},"pattern":{"fillmode":"overlay","size":10,"solidity":0.2}},"type":"barpolar"}],"pie":[{"automargin":true,"type":"pie"}]},"layout":{"autotypenumbers":"strict","colorway":["#636efa","#EF553B","#00cc96","#ab63fa","#FFA15A","#19d3f3","#FF6692","#B6E880","#FF97FF","#FECB52"],"font":{"color":"#2a3f5f"},"hovermode":"closest","hoverlabel":{"align":"left"},"paper_bgcolor":"white","plot_bgcolor":"#E5ECF6","polar":{"bgcolor":"#E5ECF6","angularaxis":{"gridcolor":"white","linecolor":"white","ticks":""},"radialaxis":{"gridcolor":"white","linecolor":"white","ticks":""}},"ternary":{"bgcolor":"#E5ECF6","aaxis":{"gridcolor":"white","linecolor":"white","ticks":""},"baxis":{"gridcolor":"white","linecolor":"white","ticks":""},"caxis":{"gridcolor":"white","linecolor":"white","ticks":""}},"coloraxis":{"colorbar":{"outlinewidth":0,"ticks":""}},"colorscale":{"sequential":[[0.0,"#0d0887"],[0.1111111111111111,"#46039f"],[0.2222222222222222,"#7201a8"],[0.3333333333333333,"#9c179e"],[0.4444444444444444,"#bd3786"],[0.5555555555555556,"#d8576b"],[0.6666666666666666,"#ed7953"],[0.7777777777777778,"#fb9f3a"],[0.8888888888888888,"#fdca26"],[1.0,"#f0f921"]],"sequentialminus":[[0.0,"#0d0887"],[0.1111111111111111,"#46039f"],[0.2222222222222222,"#7201a8"],[0.3333333333333333,"#9c179e"],[0.4444444444444444,"#bd3786"],[0.5555555555555556,"#d8576b"],[0.6666666666666666,"#ed7953"],[0.7777777777777778,"#fb9f3a"],[0.8888888888888888,"#fdca26"],[1.0,"#f0f921"]],"diverging":[[0,"#8e0152"],[0.1,"#c51b7d"],[0.2,"#de77ae"],[0.3,"#f1b6da"],[0.4,"#fde0ef"],[0.5,"#f7f7f7"],[0.6,"#e6f5d0"],[0.7,"#b8e186"],[0.8,"#7fbc41"],[0.9,"#4d9221"],[1,"#276419"]]},"xaxis":{"gridcolor":"white","linecolor":"white","ticks":"","title":{"standoff":15},"zerolinecolor":"white","automargin":true,"zerolinewidth":2},"yaxis":{"gridcolor":"white","linecolor":"white","ticks":"","title":{"standoff":15},"zerolinecolor":"white","automargin":true,"zerolinewidth":2},"scene":{"xaxis":{"backgroundcolor":"#E5ECF6","gridcolor":"white","linecolor":"white","showbackground":true,"ticks":"","zerolinecolor":"white","gridwidth":2},"yaxis":{"backgroundcolor":"#E5ECF6","gridcolor":"white","linecolor":"white","showbackground":true,"ticks":"","zerolinecolor":"white","gridwidth":2},"zaxis":{"backgroundcolor":"#E5ECF6","gridcolor":"white","linecolor":"white","showbackground":true,"ticks":"","zerolinecolor":"white","gridwidth":2}},"shapedefaults":{"line":{"color":"#2a3f5f"}},"annotationdefaults":{"arrowcolor":"#2a3f5f","arrowhead":0,"arrowwidth":1},"geo":{"bgcolor":"white","landcolor":"#E5ECF6","subunitcolor":"white","showland":true,"showlakes":true,"lakecolor":"white"},"title":{"x":0.05},"mapbox":{"style":"light"}}},"xaxis":{"anchor":"y","domain":[0.0,1.0],"title":{"text":"GDP ($ trillions)"},"gridcolor":"lightgrey"},"yaxis":{"anchor":"x","domain":[0.0,1.0],"title":{"text":"Temperature Anomaly(Degree C)"},"gridcolor":"lightgrey"},"legend":{"tracegroupgap":0},"title":{"text":"Temperature Anomaly vs. World GDP"}},                        {"responsive": true}                    ).then(function(){

var gd = document.getElementById('97e5b2d8-50bd-4797-9bb4-865ffcfc5781');
var x = new MutationObserver(function (mutations, observer) {{
        var display = window.getComputedStyle(gd).display;
        if (!display || display === 'none') {{
            console.log([gd, 'removed!']);
            Plotly.purge(gd);
            observer.disconnect();
        }}
}});

// Listen for the removal of the full notebook cells
var notebookContainer = gd.closest('#notebook-container');
if (notebookContainer) {{
    x.observe(notebookContainer, {childList: true});
}}

// Listen for the clearing of the current output cell
var outputEl = gd.closest('.output');
if (outputEl) {{
    x.observe(outputEl, {childList: true});
}}

                        })                };                            </script>        </div>
</body>
</html>


Source: The World Bank and National Oceanic and Atmospheric Administration, Earth System Research Laboratory, Global Monitoring Division


```python
correlation = data['World GDP'].corr(data['Temperature Anomaly'])
print(f"The Pearson correlation coefficient is: {correlation}")
```

    The Pearson correlation coefficient is: 0.9317515940963721


The graph shows more clearly that as the world GDP increases throughout the years, the temperature anomaly also tends to increase.

The Pearson correlation coefficient for this set of data is 0.9317515940963721, which indicates a very strong positive linear relationship between the temperature anomaly and the World GDP.

This could suggest that as economic activity (measured by GDP) increases, there is a corresponding increase in the average temperature anomaly, which could be interpreted as an indicator of global warming.

### 4.2. Ecological State (Temperature Anamoly & CO2 Emissions) vs. World GDP


```python
carbon_temp_gdp_df = pd.read_csv('carbon_temp_gdp_df.csv')
```


```python
carbon_temp_gdp_df.head()
```





  <div id="df-efe7b5f5-cd95-41ee-98e6-477b709bcec8" class="colab-df-container">
    <div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Year</th>
      <th>Annual CO₂ emissions</th>
      <th>Temperature Anomaly\n(deg C)</th>
      <th>Smoothed Temperature Anomaly\n(deg C)</th>
      <th>total_gdp</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>1750</td>
      <td>55835622.0</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>0.0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>1751</td>
      <td>56443374.0</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>0.0</td>
    </tr>
    <tr>
      <th>2</th>
      <td>1752</td>
      <td>57031008.0</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>0.0</td>
    </tr>
    <tr>
      <th>3</th>
      <td>1753</td>
      <td>57662940.0</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>0.0</td>
    </tr>
    <tr>
      <th>4</th>
      <td>1754</td>
      <td>58401480.0</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>0.0</td>
    </tr>
  </tbody>
</table>
</div>
    <div class="colab-df-buttons">

  <div class="colab-df-container">
    <button class="colab-df-convert" onclick="convertToInteractive('df-efe7b5f5-cd95-41ee-98e6-477b709bcec8')"
            title="Convert this dataframe to an interactive table."
            style="display:none;">

  <svg xmlns="http://www.w3.org/2000/svg" height="24px" viewBox="0 -960 960 960">
    <path d="M120-120v-720h720v720H120Zm60-500h600v-160H180v160Zm220 220h160v-160H400v160Zm0 220h160v-160H400v160ZM180-400h160v-160H180v160Zm440 0h160v-160H620v160ZM180-180h160v-160H180v160Zm440 0h160v-160H620v160Z"/>
  </svg>
    </button>

  <style>
    .colab-df-container {
      display:flex;
      gap: 12px;
    }

    .colab-df-convert {
      background-color: #E8F0FE;
      border: none;
      border-radius: 50%;
      cursor: pointer;
      display: none;
      fill: #1967D2;
      height: 32px;
      padding: 0 0 0 0;
      width: 32px;
    }

    .colab-df-convert:hover {
      background-color: #E2EBFA;
      box-shadow: 0px 1px 2px rgba(60, 64, 67, 0.3), 0px 1px 3px 1px rgba(60, 64, 67, 0.15);
      fill: #174EA6;
    }

    .colab-df-buttons div {
      margin-bottom: 4px;
    }

    [theme=dark] .colab-df-convert {
      background-color: #3B4455;
      fill: #D2E3FC;
    }

    [theme=dark] .colab-df-convert:hover {
      background-color: #434B5C;
      box-shadow: 0px 1px 3px 1px rgba(0, 0, 0, 0.15);
      filter: drop-shadow(0px 1px 2px rgba(0, 0, 0, 0.3));
      fill: #FFFFFF;
    }
  </style>

    <script>
      const buttonEl =
        document.querySelector('#df-efe7b5f5-cd95-41ee-98e6-477b709bcec8 button.colab-df-convert');
      buttonEl.style.display =
        google.colab.kernel.accessAllowed ? 'block' : 'none';

      async function convertToInteractive(key) {
        const element = document.querySelector('#df-efe7b5f5-cd95-41ee-98e6-477b709bcec8');
        const dataTable =
          await google.colab.kernel.invokeFunction('convertToInteractive',
                                                    [key], {});
        if (!dataTable) return;

        const docLinkHtml = 'Like what you see? Visit the ' +
          '<a target="_blank" href=https://colab.research.google.com/notebooks/data_table.ipynb>data table notebook</a>'
          + ' to learn more about interactive tables.';
        element.innerHTML = '';
        dataTable['output_type'] = 'display_data';
        await google.colab.output.renderOutput(dataTable, element);
        const docLink = document.createElement('div');
        docLink.innerHTML = docLinkHtml;
        element.appendChild(docLink);
      }
    </script>
  </div>


<div id="df-ccfd171d-762e-4e3b-8903-d01fe12fbe5a">
  <button class="colab-df-quickchart" onclick="quickchart('df-ccfd171d-762e-4e3b-8903-d01fe12fbe5a')"
            title="Suggest charts"
            style="display:none;">

<svg xmlns="http://www.w3.org/2000/svg" height="24px"viewBox="0 0 24 24"
     width="24px">
    <g>
        <path d="M19 3H5c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2zM9 17H7v-7h2v7zm4 0h-2V7h2v10zm4 0h-2v-4h2v4z"/>
    </g>
</svg>
  </button>

<style>
  .colab-df-quickchart {
      --bg-color: #E8F0FE;
      --fill-color: #1967D2;
      --hover-bg-color: #E2EBFA;
      --hover-fill-color: #174EA6;
      --disabled-fill-color: #AAA;
      --disabled-bg-color: #DDD;
  }

  [theme=dark] .colab-df-quickchart {
      --bg-color: #3B4455;
      --fill-color: #D2E3FC;
      --hover-bg-color: #434B5C;
      --hover-fill-color: #FFFFFF;
      --disabled-bg-color: #3B4455;
      --disabled-fill-color: #666;
  }

  .colab-df-quickchart {
    background-color: var(--bg-color);
    border: none;
    border-radius: 50%;
    cursor: pointer;
    display: none;
    fill: var(--fill-color);
    height: 32px;
    padding: 0;
    width: 32px;
  }

  .colab-df-quickchart:hover {
    background-color: var(--hover-bg-color);
    box-shadow: 0 1px 2px rgba(60, 64, 67, 0.3), 0 1px 3px 1px rgba(60, 64, 67, 0.15);
    fill: var(--button-hover-fill-color);
  }

  .colab-df-quickchart-complete:disabled,
  .colab-df-quickchart-complete:disabled:hover {
    background-color: var(--disabled-bg-color);
    fill: var(--disabled-fill-color);
    box-shadow: none;
  }

  .colab-df-spinner {
    border: 2px solid var(--fill-color);
    border-color: transparent;
    border-bottom-color: var(--fill-color);
    animation:
      spin 1s steps(1) infinite;
  }

  @keyframes spin {
    0% {
      border-color: transparent;
      border-bottom-color: var(--fill-color);
      border-left-color: var(--fill-color);
    }
    20% {
      border-color: transparent;
      border-left-color: var(--fill-color);
      border-top-color: var(--fill-color);
    }
    30% {
      border-color: transparent;
      border-left-color: var(--fill-color);
      border-top-color: var(--fill-color);
      border-right-color: var(--fill-color);
    }
    40% {
      border-color: transparent;
      border-right-color: var(--fill-color);
      border-top-color: var(--fill-color);
    }
    60% {
      border-color: transparent;
      border-right-color: var(--fill-color);
    }
    80% {
      border-color: transparent;
      border-right-color: var(--fill-color);
      border-bottom-color: var(--fill-color);
    }
    90% {
      border-color: transparent;
      border-bottom-color: var(--fill-color);
    }
  }
</style>

  <script>
    async function quickchart(key) {
      const quickchartButtonEl =
        document.querySelector('#' + key + ' button');
      quickchartButtonEl.disabled = true;  // To prevent multiple clicks.
      quickchartButtonEl.classList.add('colab-df-spinner');
      try {
        const charts = await google.colab.kernel.invokeFunction(
            'suggestCharts', [key], {});
      } catch (error) {
        console.error('Error during call to suggestCharts:', error);
      }
      quickchartButtonEl.classList.remove('colab-df-spinner');
      quickchartButtonEl.classList.add('colab-df-quickchart-complete');
    }
    (() => {
      let quickchartButtonEl =
        document.querySelector('#df-ccfd171d-762e-4e3b-8903-d01fe12fbe5a button');
      quickchartButtonEl.style.display =
        google.colab.kernel.accessAllowed ? 'block' : 'none';
    })();
  </script>
</div>

    </div>
  </div>





```python
# Create a figure and axis objects with a larger figure size
fig, ax1 = plt.subplots(figsize=(12, 8))

# Plot the Temperature Anomaly columns
ax1.plot(carbon_temp_gdp_df['Year '], carbon_temp_gdp_df['Temperature Anomaly\n(deg C)'], color='red', label='Temperature Anomaly')
ax1.plot(carbon_temp_gdp_df['Year '], carbon_temp_gdp_df['Smoothed Temperature Anomaly\n(deg C)'], color='orange', label='Smoothed Temperature Anomaly')
ax1.set_ylabel('Temperature Anomaly (Degrees Celsius)')

# Create a second y-axis for total_gdp and annual CO₂ emissions
ax2 = ax1.twinx()
ax2.plot(carbon_temp_gdp_df['Year '], carbon_temp_gdp_df['total_gdp'], color='blue', label='Total GDP')
ax2.plot(carbon_temp_gdp_df['Year '], carbon_temp_gdp_df['Annual CO₂ emissions'], color='green', label='Annual CO₂ emissions')
ax2.set_ylabel('Total GDP (Billions) / Annual CO₂ emissions (Billions)')

# Set the labels and legends
ax1.set_xlabel('Year')
ax1.legend(loc='upper left')
ax2.legend(loc='upper right')

# Display the graph
plt.title('Carbon Emissions, Temperature Anomaly, and Total GDP Over Time')
plt.show()
```


    
![png](Why_GDP_lecture_files/Why_GDP_lecture_64_0.png)
    



```python

```
